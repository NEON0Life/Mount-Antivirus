#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
#Логирование Ошибок
from loguru import logger
import subprocess
import random
import shutil
import sys
import os
#from pyqadmin import admin

from LR import Create_Label

CaC_version = "0.6.10 beta"

def Run_Command(command):
    #Запускает команду и ждём её завершения
    process = subprocess.run(command, shell=True)
    return process.returncode


#@admin
def Move_All_Files(src_folder, dest_folder):
    #Перемещает все содержимое указанной папки в другую папку
    try:
        for item in os.listdir(src_folder):
            src_path = os.path.join(src_folder, item)
            dest_path = os.path.join(dest_folder, item)
            if os.path.isdir(src_path):
                shutil.copytree(src_path, dest_path)
            else:
                shutil.move(src_path, dest_path)
        print(f"Содержимое {src_folder} перемещено в {dest_folder}.")
    except Exception as e:
        print(f"Ошибка при перемещении файлов: {e}")



def Update_Confing(file_name, LP_path, PH2_path, PH2_path_old, ATM_path, ATM_path_old):
    #Получаем размер файла в байтах
    try:
        file_size = os.path.getsize(file_name)
        file_size = int(file_size)
    except FileNotFoundError:
        print(f"Файл {file_name} не найден.")
        file_size = 0

    #Если размер файла успешно получен, записываем его вес в config.py
    if file_size != 0:
        with open("config.py", "a") as config_file:
            if file_name == LP_path:
                config_file.write(f'\nLP_size = {file_size}\n')
                print(f"Вес файла {file_name} равен {file_size} байт, и записан в config.py")
            if file_name == PH2_path_old:
                config_file.write(f'\nPH2_size = {file_size}\n')
                print(f"Вес файла {file_name} равен {file_size} байт, и записан в config.py")
            if file_name == ATM_path_old:
                config_file.write(f'\nATM_size = {file_size}\n')
                print(f"Вес файла {file_name} равен {file_size} байт, и записан в config.py")



def Rename_Files(old_name, new_name):
    try:
        os.rename(old_name, new_name)
        print(f"Файл '{old_name}' был успешно переименован в '{new_name}'")
    except FileNotFoundError:
        print(f"Файл '{old_name}' не найден.")
    except Exception as e:
        print(f"Произошла ошибка при переименовании файла {old_name} на {new_name}:\n {str(e)}")



#@admin
def Move_Files(path_to_setup, image_path, T_path, LP_path):
    #Перемещаем Компоненты
    shutil.copy(T_path, path_to_setup)
    shutil.copy(LP_path, path_to_setup)

    #Перемещаем содержимое папки info_image
    info_image_folder = "info_image"
    Move_All_Files(info_image_folder, image_path)

    #Перемещаем содержимое папки media в C:\\Windows\\Media\\
    data_folder = "media"
    Move_All_Files(data_folder, "C:\\Windows\\Media\\")



#Переименовывание Компонентов
def Conversus_Extensio_To_Exe(filename):
    #Убираем последние 3 символа, да бы избавится от расширения .py
    new_filename = filename[:-3]
    #Добавляем расширение .exe в конце
    new_filename += ".exe"
    return new_filename



@logger.catch
def Compilation(path_to_setup, T_path, LP_path, image_path, ATM_path, ATM_path_old, PH2_path, PH2_path_old):
    #Первая команда
    Rename_Files("LP.py", LP_path)
    Rename_Files("T.py", T_path)
    print("Компиляция Компонента LoadProtection запущена...")
    if Run_Command(f'python -m nuitka --follow-imports --standalone --windows-console-mode=disable --onefile --enable-plugin=tk-inter --windows-icon-from-ico=icon\\LP_icon.ico {LP_path}') == 0:
        print("Компиляция Компонента LoadProtection завершена!")

        LP_path = Conversus_Extensio_To_Exe(LP_path)

        #Обновляем config.py, записывая туда вес Компонентов
        Update_Confing(LP_path, LP_path, PH2_path, PH2_path_old, ATM_path, ATM_path_old)
        Update_Confing(PH2_path_old, LP_path, PH2_path, PH2_path_old, ATM_path, ATM_path_old)
        Update_Confing(ATM_path_old, LP_path, PH2_path, PH2_path_old, ATM_path, ATM_path_old)

        #Вторая команда
        print("Компиляция Компонента Trey запущена...")
        if Run_Command(f'python -m nuitka --follow-imports --standalone --windows-console-mode=disable --onefile --enable-plugin=tk-inter --windows-icon-from-ico=icon\\T_icon.ico {T_path}') == 0:
            print("Компиляция Компонента Trey завершена!")

            T_path = Conversus_Extensio_To_Exe(T_path)
            Rename_Files(PH2_path_old, PH2_path)
            Rename_Files(ATM_path_old, ATM_path)

            #Перемещаем файлы
            Move_Files(path_to_setup, image_path, T_path, LP_path)
            
            print("Процесс Компиляции и Установки Компонентов успешно завершён.")
            target_exe = path_to_setup + f"\\{T_path}"
            n = random.randint(4, 15)
            label_name = ''.join(random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(n))
            label_name = label_name + ".lnk"
            Create_Label(target_exe, label_name)
        else:
            comment = f"Ошибка при компиляции Компонента Trey!\n{str(e)}"
            print(comment)
            logger.error(comment)
    else:
        comment = f"Ошибка при компиляции Компонента LoadProtection!\n{str(e)}"
        print(comment)
        logger.error(comment)