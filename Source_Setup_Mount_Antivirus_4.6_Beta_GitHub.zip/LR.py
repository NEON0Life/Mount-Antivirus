#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
import os
import sys
import winreg as reg
import win32com.client
#Логирование Ошибок
from loguru import logger
from tkinter import messagebox
#from pyqadmin import admin

LR_version = "0.2.3 beta"

#@admin
def T_in_run(target_path):
    try:
        #Открываем ключ реестра для редактирования
        registry_key = reg.OpenKey(reg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\", 0, reg.KEY_WRITE)

        #Заменяем значение
        reg.SetValueEx(registry_key, "Userinit", 0, reg.REG_SZ, rf"C:\Windows\System32\userinit.exe, {target_path}")

        #Закрываем ключ реестра
        reg.CloseKey(registry_key)
        print(f"Значение Userinit успешно изменено на C:\\Windows\\System32\\userinit.exe, {target_path}")

    except PermissionError:
        print("Даному Програмному Обеспечению необходимы права администратора для изменения реестра!")
    except Exception as e:
        print(f"Произошла ошибка: {str(e)}")
        logger.error(f"Ошибка при довалении программы в автозапуск\n{str(e)}")

    messagebox.showinfo("Установка Завершена!", "Установка выполнена успешно(но это не точно)\nПРЕДУПРЕЖДЕНИЕ!\nПрограмма находится в Pre-Alpha Тестировании! Просьба при возникновении ошибок сообщять нам и не обижатся\nПРЕДУПРЕЖДЕНИЕ 2!\nПрограмма была добавлена в автозагрузку через реестр в параемтр usernit!\n\nБлагодарим за установку даного Програмного Обеспечения!")



@logger.catch
def Create_Label(target_path, shortcut_name):
    #Получаем путь к рабочему столу
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    
    #Полный путь к ярлыку
    shortcut_path = os.path.join(desktop_path, f"{shortcut_name}.lnk")

    #Создаем объект Shell
    shell = win32com.client.Dispatch("WScript.Shell")
    
    #Создаем ярлык
    shortcut = shell.CreateShortCut(shortcut_path)
    shortcut.TargetPath = target_path
    shortcut.WorkingDirectory = os.path.dirname(target_path) #Рабочая папка ярлыка
    shortcut.save() #Сохраняем ярлык

    print(f"Ярлык успешно создан на рабочем столе!")

    T_in_run(target_path)