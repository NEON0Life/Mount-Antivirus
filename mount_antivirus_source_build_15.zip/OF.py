#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
#Интерфейс
from tkinter import ttk, messagebox, filedialog
#Логирование Ошибок
from loguru import logger
#Работа с реестром
import winreg as reg
#Работа с процессами
import subprocess
#Работа с файлами и ОС
import sys
import os

from RS import Random_String
from config import *

global file, file_size_o, LP_size, LP_path, ATM_path, ATM_size, PH2_path, PH2_size
other_komponents_version = "0.4.0 beta"

#Запукс Компонентов
@logger.catch
def Run_Komponent(file, file_size_o):
    try:
        #Проверяем, существует ли файл
        if not os.path.isfile(file):
            print("Файл не найден.")
            return

        #Получаем размер файла в байтах
        file_size = os.path.getsize(file)
        print(f"Размер файла: {file_size} байт")

        #Проверяем размер файла
        if file_size != file_size_o:
            comment = f"Размер файла {file} не равен {file_size_o} байтам. Компонент не будет запущена!\nВОЗМОЖНОЕ УГРОЗА СИСТЕМЕ!"
            print(comment)
            logger.error(comment)
            return

        #Запускаем файл
        if file_size == file_size_o:
            try:
                os.startfile(file)
            except Exception as e:
                logger.error(f"Ошибка при запуске файла {file}")

    except Exception as e:
        logger.error(f"Неизвестаня ошибка в Компоеннте OthetFunctions! В функции Run_Komponent!\n{str(e)}")



#Открыть С помощью
@logger.catch
def Open_With():
    target_file_path = filedialog.askopenfilename(title="Выберите файл для открытия", filetypes=[("Все файлы", "*.*")])
    if target_file_path and os.path.isfile(target_file_path): #Проверка, что файл выбран и существует
        app_path = filedialog.askopenfilename(title="Выберите программу для открытия файла", filetypes=[("Все файлы", "*.*")])
        if app_path:
            try:
                subprocess.Popen([app_path, target_file_path])
            except Exception as e:
                logger.error(f"Не удалось открыть файл '{target_file_path}'с помощью указанной программы '{app_path}'\n{str(e)}")
                Random_String()
                messagebox.showerror(random_string, f"Не удалось открыть файл с помощью указанной программы:\n{str(e)}")



@logger.catch
def Reg_File(reg_file, reg_code):
    with open(reg_file, "w") as reg:
        reg.write(reg_code)
    try:
        os.startfile(reg_file)
    except Exception as e:
        comment = f"Ошибка при запуске {reg_file}, ВОЗМОЖНАЯ УГРОЗА СИСТЕМЕ!\n{str(e)}"
        print(comment)
        logger.error(comment)



#Вызов функции Run_Komponent происхожит от сюда дабы программа при запуске не запускала все компоненты подряд (кароче де-баг)
@logger.catch
def LP():
    Run_Komponent(LP_path, LP_size)
@logger.catch
def ATM():
    Run_Komponent(ATM_path, ATM_size)
@logger.catch
def PH2():
    Run_Komponent(PH2_path, PH2_size)