#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
#Рисование иконки в трее и вставка картинок
from PIL import Image, ImageDraw, ImageFont, ImageTk
#Графический Интерфейс
from tkinter import messagebox, filedialog
from tkinter import ttk
import tkinter as tk
#Логирование Ошибок
from loguru import logger
#Движок иконки в трее
from pystray import MenuItem, Menu
import pystray
#Дата и Время
from datetime import datetime
#Получение прав Администратора
from elevate import elevate
#Реестр windows
import winreg as reg
#Обращение к веб-браузеру
import webbrowser
#Вроде как оптимизация
import threading
#Генерация Текста
import random
#Обращение к Системным Командам и Значениям
import sys
import os

#Импорт Компонентов
from E import E
from R import R
from AR import AR
from CC import CC
from MU import MU
from Run import Run
from config import *
from CC22 import CC22
from exit_T import Ask_Exit
from RS import Random_String
from AP import About_Program
from OF import Run_Komponent, Open_With, LP, ATM, PH2, Reg_File

elevate()

#Глобальные Переменные
global clyth, T_log_txt, settings_path, message_txt, font_recovery_reg, font_recovery_text, cursors_recovery_reg, cursors_recovery_text
result = ""
font_trey = "arial.ttf"
trey_version = "1.8.6 Pre-Alpha Build 15"

if not os.path.exists(log_path):
    os.makedirs(log_path)
logger.add(f"{log_path}\\{T_log_txt}", format="{time} {level} {message}", level="ERROR", rotation="100 KB", compression="zip")

try:
    #Создание Иконки
    def Create_Image(width, height):
        #Создаем Изображение
        image = Image.new("RGB", (width, height), (255, 0, 0))
        dc = ImageDraw.Draw(image)

        #Рисуем Синий Квадрат
        dc.rectangle(
            (width // 2 - 10, height // 2 - 10, width // 2 + 10, height // 2 + 10),
            fill=(0, 0, 255)
        )

        #Задаем Шрифт и размер текста
        try:
            font = ImageFont.truetype(font_trey, 24)
        except IOError:
            font = ImageFont.load_default()
            logger.error(f"Ошибка при загрузки шрифта {font_trey} из системы!")
        except Exception as e:
            logger.error(f"Ошибка при загрузки шрифта по умолчанию!\n{str(e)}")

        #Рисуем Красный Смайлик
        text = "=]"
        text_bbox = dc.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        
        text_position = (width // 2 - text_width // 2, height // 2 - text_height // 2)
        dc.text(text_position, text, fill=(255, 0, 0), font=font)

        return image

    #Восставноление Шрифтов
    #def Recovery_Font():
        #Reg_File(font_recovery_reg, font_recovery_text)

    #Восстановление Курсоров
    #def Recovery_Cursors():
        #Reg_File(cursors_recovery_reg, cursors_recovery_text)

    #Запуск Иконки в трее
    def Start_Icon(icon):
        icon.visible = True



    #Создаем выпадающий список с функциями Анлокера
    unlocker_menu = Menu(
        MenuItem("Файловый Менеджер", E),
        MenuItem("Мастер Автозагрузки", AR),
        MenuItem("AnvirTaskManager", ATM),
        MenuItem("Запустить Очистку Temp", CC),
        #MenuItem("ВОССТАНОВИТЬ ШРИФТЫ00000000000", Recovery_Font),
        #MenuItem("ВОССТАНОВИТЬ КУРСОРЫ", Recovery_Cursors),
        MenuItem("Открыть с Помощью", Open_With),
        MenuItem("Перезапустить ПК", R)
    )

    #Меню По ПКМ
    image = Create_Image(20, 20)
    menu = Menu(
        MenuItem("Открыть Монтировка Анлокер", MU),
        MenuItem("Утилиты", unlocker_menu),
        MenuItem("Запустить Load Protection", LP),
        MenuItem("ProcessHaker", PH2),
        MenuItem("Запустить От Имени Админа", Run),
        MenuItem("О Программе", About_Program),
        #MenuItem("Настройки", Settings),
        MenuItem("Выход", Ask_Exit)
    )

    icon = pystray.Icon("MULTIVAC_ICON", image, "MULTIVAC", menu)
    icon.run(Start_Icon)

    #Запускаем Иконку в отдельном потоке
    threading.Thread(target=Start_Icon).start()

except Exception as e:
    logger.error(f"Неизвестная ошибка в Компоненте Trey!\n{str(e)}")