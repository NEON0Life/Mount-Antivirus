#Coded by @AnonimNEO
from tkinter import messagebox, Tk
from datetime import datetime
from elevate import elevate
from loguru import logger
from pathlib import Path
from pygame import mixer
import tkinter as tk
#import threading
import pystray
#import GPUtil
import psutil
import time
import sys
import os

mixer.init()

elevate()

#Глобальные Переменные
global version, bad_process, clyth, time_sleep_to_scan, ultimate_load_cpu, ultimate_load_gpu,ultimate_load_ram, ultimate_load_lan, exceptions_proc, LP_log_txt, emergency_alert_mp3, exception_process_txt, ultimate_load_lan_txt, ultimate_load_ram_txt, ultimate_load_gpu_txt, ultimate_load_cpu_txt, bad_process_txt, message_txt, settings_path
version = "1.2.15 Pre-Alpha Build 15"

from config import *
from CC22 import CC22
from RS import Random_String

if not os.path.exists(log_path):
    os.makedirs(log_path)
logger.add(f"{log_path}\\{LP_log_txt}", format="{time} {level} {message}", level="ERROR", rotation="100 KB", compression="zip")
logger.add(f"{log_path}\\{LP_log_txt}", format="{time} {level} {message}", level="INFO", rotation="100 KB", compression="zip")

#ВНИМАНИЕ! Если раскоментировать строки для логирования ошибок получения нагрузки на GPU и LAN, то программа бесконечно будет дополнять файл log_LP.txt при это вес будет увеличиватся на (примерно) 10КБ в секунду!
#ВНИМАНИЕ2! Если раскоментировать строки для полной работы программы (тоесть функции связаные с GPU и LAN), программа не сможет работать адекватно, (лог файл будет увеличиватся ещё больше) + бесконечное открывание и закрывание консолей из-за сканирования GPU

try:
    #Функция Чтения натсроек
    def load_settings():
        global message
        if not os.path.exists(settings_path):
            os.makedirs(settings_path)
            with open(f"{settings_path}\\{message_txt}", "w") as file:
                file.write("False")
            print(f"Файл {settings_path}\\{message_txt} создан со значением False")
        if not os.path.isfile(f"{settings_path}\\{message_txt}"):
            with open(f"{settings}\\{message_txt}", "w") as file:
                file.write("False")
            print(f"Файл {settings_path}\\{message_txt} создан со значением False")
        with open(f"{settings_path}\\{message_txt}", "r") as file:
            message = file.read()
        if message == "True":
            print("1-ая праверка переменной message пройдена")
            mepr = 1
        if message == "False":
            print("2-ая проверка переменной message пройдена")
            mepr = 1
        if mepr == 0:
            message = "False"
            with open(f"{settings_path}\\{message_txt}", "w") as file:
                file.write("False")
            print(f"Файл {settings_path}\\{message_txt} создан со значением False")



    #Получайем Дополнительный список плохих процессов
    def load_bad_processes():
        global bad_process
        try:
            with open(f"{settings_path}\\{bad_process_txt}", "r") as file:
                bad_process = [line.strip() for line in file.readlines() if line.strip()]
        except Exception as e:
            logger.error(f"Ошибка загрузки списка плохих процессов\n{str(e)}")
            with open(f"{settings_path}\\{bad_process_txt}", "w") as file:
                file.write("")



    #Загрузка Настроек
    def load_settings():
        global ultimate_load_cpu, ultimate_load_gpu, ultimate_load_ram, ultimate_load_lan
        #lan_file = f"{settings_path}\\{ultimate_load_lan_txt}"
        cpu_file = f"{settings_path}\\{ultimate_load_cpu_txt}"
        #gpu_file = f"{settings_path}\\{ultimate_load_gpu_txt}"
        ram_file = f"{settings_path}\\{ultimate_load_ram_txt}"

        try:
            with open(cpu_file, "r") as file:
                encrypted_cpu = file.read()
                ultimate_load_cpu = float(CC22(encrypted_cpu, clyth, True)) #Расшифровка
        except Exception as e:
            ultimate_load_cpu = 45 #Значение По Умолчанию
            logger.error(f"Ошибка загрузки CPU\n{str(e)}")

        #try:
            #with open(gpu_file, "r") as file:
                #encrypted_gpu = file.read()
                #ultimate_load_gpu = float(CC22(encrypted_gpu, clyth, True)) #Расшифровка
        #except Exception as e:
            #ultimate_load_gpu = 45 #Значение По Умолчанию
            #logger.error(f"Ошибка загрузки GPU\n{str(e)}")

        try:
            with open(ram_file, "r") as file:
                encrypted_ram = file.read()
                ultimate_load_ram = float(CC22(encrypted_ram, clyth, True)) #Расшифровка
        except Exception as e:
            ultimate_load_ram = 45 #Значение По Умолчанию
            logger.error(f"Ошибка загрузки RAM\n{str(e)}")

        #try:
            #with open(lan_file, "r") as file:
                #encrypted_lan = file.read()
                #ultimate_load_lan = float(CC22(encrypted_lan, clyth, True)) #Расшифровка
        #except Exception as e:
            #ultimate_load_lan = 15 #Значение По Умолчанию
            #logger.error(f"Ошибка загрузки LAN\n{str(e)}")

        save_settings()



    #Созранение Настроек
    def save_settings():
        #lan_file = f"{settings_path}\\{ultimate_load_lan_txt}"
        cpu_file = f"{settings_path}\\{ultimate_load_cpu_txt}"
        #gpu_file = f"{settings_path}\\{ultimate_load_gpu_txt}"
        ram_file = f"{settings_path}\\{ultimate_load_ram_txt}"

        try:
            with open(cpu_file, "w") as file:
                file.write(CC22(str(ultimate_load_cpu), clyth)) #Шифрование
            #with open(gpu_file, "w") as file:
                #file.write(CC22(str(ultimate_load_gpu), clyth)) #Шифрование
            with open(ram_file, "w") as file:
                file.write(CC22(str(ultimate_load_ram), clyth)) #Шифрование
            #with open(lan_file, "w") as file:
                #file.write(CC22(str(ultimate_load_lan), clyth)) #Шифрование
        except Exception as e:
            logger.error(f"Ошибка сохранения настроек\n{str(e)}")

    #Загружаем Настройки
    load_settings()



    #Получаем Нагрузку на GPU
    def get_gpu_usage(pid):
        try:
            #gpus = GPUtil.getGPUs() #Получаем список доступных GPU
            #for gpu in gpus:
                #process_list = gpu.processes
                #for process in process_list:
                    #if process["pid"] == pid:
                        #return process["gpu_load"] * 100 #Возвращаем % Загрузки GPU
            return 0 #Если Процесс не найден, возвращаем 0
        except Exception as e:
            #logger.error(f"Ошибка получения нагрузки на GPU для PID {pid}\n{str(e)}")
            return 0 #Возвращаем 0 в случае ошибки



    #Получаем Нагрузку на RAM
    def get_ram_usage(pid):
        try:
            process = psutil.Process(pid)
            return process.memory_percent()
        except Exception as e:
            logger.error(f"Ошибка получения нагрузки на RAM для PID {pid}\n{str(e)}")
            return 0



    #Получаем Нагрузку на LAN (в байтах)
    def get_lan_usage(pid):
        try:
            return 0
            #process = psutil.Process(pid)
            #net_io = process.io_counters()
            #return net_io.bytes_sent + net_io.bytes_recv #Возвращаем общее количество переданных и полученных байтов
        except Exception as e:
            #logger.error(f"Ошибка получения нагрузки на LAN для PID {pid}\m{str(e)}")
            return 0



    #Добавляем Искоючение в переменную
    def add_exception(process_name):
        global exceptions_proc
        if process_name not in exceptions_proc:
            exceptions_proc.append(process_name)
            save_exceptions()
            random_string = Random_String()
            comment = f"Процесс {process_name} добавлен в список исключений."
            logger.info(comment)
            messagebox.showinfo(random_string, comment)
        else:
            random_string = Random_String()
            comment = f"Процесс {process_name} уже в списке исключений."
            logger.info(f"Процесс {process_name} уже в списке исключений.")
            messagebox.showinfo(random_string, comment)



    #Сохраняем Исключение в базу дыннх
    def save_exceptions():
        try:
            with open(f"{settings_path}\\{exception_process_txt}", "w") as file:
                encrypted_exceptions = CC22(', '.join(exceptions_proc), clyth)
                file.write(encrypted_exceptions)
        except Exception as e:
            logger.error(f"Ошибка записи в файл исключений\n{str(e)}")



    #Читаем и Расшифровываем Файл Исключений
    def load_exceptions():
        global exceptions_proc
        try:
            with open(f"{settings_path}\\{exception_process_txt}", "r") as file:
                encrypted_exceptions = file.read()
                decrypted_exceptions = CC22(encrypted_exceptions, clyth, True) #Расшифровка
                exceptions_proc = [line.strip() for line in decrypted_exceptions.split(",") if line.strip()]
        except Exception as e:
            logger.error(f"Ошибка загрузки списка исключений\n{str(e)}")
            #exceptions_proc = []
            save_exceptions()



    # Изменяем функцию monitor_processes
    def monitor_processes():
        for proc in psutil.process_iter(["pid", "name", "cpu_percent"]):
            try:
                if proc.info["name"] in exceptions_proc:
                    continue

                cpu_usage = proc.info["cpu_percent"]
                #gpu_usage = get_gpu_usage(proc.info["pid"])
                ram_usage = get_ram_usage(proc.info["pid"])
                #lan_usage = get_lan_usage(proc.info["pid"])

                if (cpu_usage > ultimate_load_cpu or 
                    #gpu_usage > ultimate_load_gpu or 
                    ram_usage > ultimate_load_ram or 
                    #lan_usage > ultimate_load_lan or 
                    proc.info["name"] in bad_process):
                    try:
                        proc.suspend()
                        for child in proc.children(recursive=True):
                            child.suspend()
                        notify_user(proc, is_bad_process=(proc.info["name"] in bad_process))
                    except Exception as e:
                        logger.error(f"Ошибка заморозки процесса: {proc.info["name"]}\n{str(e)}")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue



    #Уведомления
    def notify_user(proc, is_bad_process=False):
        def on_unfreeze():
            try:
                proc.resume()
                for child in proc.children(recursive=True):
                    child.resume()
                if message == True:
                    random_string = Random_String()
                    comment = f"Процесс {proc.info['name']} (PID: {proc.info['pid']}) разморожен."
                    logger.info(comment)
                    messagebox.showinfo(random_string, comment)
                
                if is_bad_process == False:
                    random_string = Random_String()
                    #Запрос на добавление в исключения
                    add_to_exceptions = messagebox.askyesno(random_string, f"Хотите добавить процесс {proc.info["name"]} (PID: {proc.info['pid']}) в список исключений?\n(если это был плохой процесс то выбор не на что не влияет.)")
                    if add_to_exceptions:
                        add_exception(proc.info["name"])

            except Exception as e:
                comment = f"Не удалось разморозить процесс {proc.info["name"]}\n{str(e)}"
                logger.error(comment)
                random_string = Random_String()
                messagebox.showerrror(random_string, comment)

        if is_bad_process:
            mixer.music.load(f"C:\\Windows\\media\\{emergency_alert_mp3}")
            mixer.music.play(3)
            random_string = Random_String()
            comment = f"Плохой процесс {proc.info["name"]} (PID: {proc.info["pid"]}) заморожен."
            logger.info(comment)
            response = messagebox.askyesno(random_string, f"{comment} Хотите разморозить?")
        else:
            random_string = Random_String()
            response = messagebox.askyesno(random_string, f"Процесс {proc.info["name"]} (PID: {proc.info["pid"]}) заморожен. Хотите разморозить?")
        
        if response: #Если пользователь нажал "Да"
            on_unfreeze()



    load_bad_processes()

    #Работа в фоновом режиме
    def run_monitor():
        while True:
            load_exceptions()
            monitor_processes()
            time.sleep(5)

    if __name__ == "__main__":
        #threading.Thread(target=run_monitor, daemon=True).start()
        run_monitor()

except Exception as e:
    comment = f"В Компоненте LoadProtection возникла неизвестная ошибка!\n{str(e)}"
    print(comment)
    logger.error(comment)