#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)

#Общее количество строчек кода
all_line = "2670"

#Глобальные Переменные
settings_path = "settings"
log_path = "log"
images_path = "info_image\\"
message_txt = "message.txt"
animation_txt = "animation.txt"
bad_process_txt = "bad_process.txt"
ultimate_load_cpu_txt = "ultimate_load_cpu.txt"
ultimate_load_gpu_txt = "ultimate_load_gpu.txt"
ultimate_load_ram_txt = "ultimate_load_ram.txt"
ultimate_load_lan_txt = "ultimate_load_network.txt"
exception_process_txt = "exception_process.txt"
emergency_alert_mp3 = "emergency_alert.mp3"
restart_windows_bat = "restart_windows.bat"
clear_temp_log = "Clear_Temp_log" 
LP_log_txt = "LP_log.txt"
MU_log_txt = "MU_log.txt"
T_log_txt = "T_log.txt"
font_recovery_reg = "font_recovery.reg"
cursors_size_txt = "cursors_size.txt"
cursors_backup_path = "Cursors_Backup"
cursors_recovery_reg = "cursors_recovery.reg"

#Ключ Шифрования
clyth = 13

#Звуки
sound_alert_path = "alert.mp3"

#T
#Каталог Компонента LoadProtection
LP_path = "LP.exe"
#Вес Файл Комонента LoadProtection в байтах
LP_size = 10879456

#OF
#код для .reg файла восстановления шрифтов
font_recovery_text = 'Windows Registry Editor Version 5.00\n[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts]\n"Segoe UI (TrueType)"="segoeui.ttf"\n"Segoe UI Black (TrueType)"="seguibl.ttf"\n"Segoe UI Black Italic (TrueType)"="seguibli.ttf"\n"Segoe UI Bold (TrueType)"="segoeuib.ttf"\n"Segoe UI Bold Italic (TrueType)"="segoeuiz.ttf"\n"Segoe UI Emoji (TrueType)"="seguiemj.ttf"\n"Segoe UI Historic (TrueType)"="seguihis.ttf"\n"Segoe UI Italic (TrueType)"="segoeuii.ttf"\n"Segoe UI Light (TrueType)"="segoeuil.ttf"\n"Segoe UI Light Italic (TrueType)"="seguili.ttf"\n"Segoe UI Semibold (TrueType)"="seguisb.ttf"\n"Segoe UI Semibold Italic (TrueType)"="seguisbi.ttf"\n"Segoe UI Semilight (TrueType)"="segoeuisl.ttf"\n"Segoe UI Semilight Italic (TrueType)"="seguisli.ttf"\n"Segoe UI Symbol (TrueType)"="seguisym.ttf"\n"Segoe MDL2 Assets (TrueType)"="segmdl2.ttf"\n"Segoe Print (TrueType)"="segoepr.ttf"\n"Segoe Print Bold (TrueType)"="segoeprb.ttf"\n"Segoe Script (TrueType)"="segoesc.ttf"\n"Segoe Script Bold (TrueType)"="segoescb.ttf"\n[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\FontSubstitutes]\n"Segoe UI"=-'

#CR
cursor_path = "C:\\Windows\\Cursors\\"
cursors_recovery_text = 'Windows Registry Editor Version 5.00\n[HKEY_CURRENT_USER\Control Panel\Cursors]\n"Scheme"="Default"'

#MU
animation_defolt = "True"

#AP
autorun_master_version = "1.5.3 Alpha"
clear_cache_version = "0.6.4 Beta"
file_manager_version = "3.5.10 Alpha"
exit_version = "1.0.7 Beta"
load_protection_version = "1.2.15 Pre-Alpha Build 15"
unlocker_version = "1.7.8 Beta"
restart_version = "0.7.4 Alpha"
run_version = "0.9.4 Beta"
random_string_version = "0.1.0"
other_komponents_version = "0.4.0 Beta"
trey_version = "1.8.6 Pre-Alpha Build 14"

#AR / LP
#Подробные уведомления в Компонентах AutoRunMaster и LoadProtection
message = "False"
#Делать ли звук тревоги при обнаружении угроз? Truey - да | False - нет
alert_sound = "True"

#R
#Через какую библиотеку выполнить перезагрузку windows
#restart_windows = "win32com.client" #НЕ СТАБИЛЬНО
#restart_windows = "os" #НЕ СТАБИЛЬНО
#restart_windows = "subprocess" #НЕ СТАБИЛЬНО
restart_windows = "bat"
#через сколько секунд выполнить перезагрузку
time_to_restart = 1
#Перезапустить ли ОС? True - да | False - нет
reboot_os = True
#Закрыть ПО принудительно? True - да | False - нет
force_software = True
error = 0

#E
#Имя пользователя по умолчанию при ошибке чтения текущего в Компоненте Explorer
user_name = "Admin"

#LP
time_to_clouse_window = 5
#Значения По Умолчанию
#Время ожидания когда Компонент LoadProtection повторит сканирование
time_sleep_to_scan = 5
#Стандартное значения предельной нагрузки на Процессор
ultimate_load_cpu = 20
#Стандартное значения предельной нагрузки на ВидеоКарту
#ultimate_load_gpu = 45
#Стандартное значения предельной нагрузки на Опреративную память
ultimate_load_ram = 35
#Стандартное значения предельной нагрузки на Интернет
#ultimate_load_lan = 15
#Стандартная база запрещёных процессов по имени
bad_process = ["42.exe", "52.exe", "1488.exe", "stalin.exe", "lenin.exe", "virus.exe", "not_a_virus.exe", "malware.exe", "sas.exe", "ass.exe", "yandex.exe", "y.exe", "ya.exe", "Yandex.exe", "Y.exe", "YA.exe", "VK.exe", "vk.exe", "Vk.exe", "vk_music.exe", "VK_MUSIC.exe", "lox.exe", "syka.exe", "вирус.exe", "не_вирус.exe", "НЕ_ВИРУС.exe", "ВИРУС.exe", "notavirus.exe", "NOTAVIRUS.exe", "NotAVirus.exe", "НеВирус.exe", "vagner.exe", "petya.exe", "a4.exe", "A4.exe", "666.exe", "satana.exe", "Satana.exe", "SATANA.exe", "negr.exe", "Negr.exe", "NEGR.exe", "loh.exe", "Loh.ex", "LOH.exe", "eblan.exe", "Eblan.exe", "EBLAN.exe", "chiledwindows.exe", "Stalin.exe", "STALIN.exe", "Lenin.exe", "LENIN.exe", "putin.exe", "Putin.exe", "PUTIN.exe", "pizda.exe", "Pizda.exe", "PIZDA.exe", "xyina.exe", "Xyina.exe", "XYINA.exe", "amogus.exe", "Amogus.exe", "AMOGUS.exe", "abobus.exe", "Abobus.exe", "ABOBUS.exe", "sex.exe", "Sex.exe", "SEX.exe", "pisun.exe", "Pisun.exe", "PISUN.exe", "bebra.exe", "Bebra.exe", "BEBRA.exe", "xyi.exe", "Xyi.exe", "XYI.exe", "сталин.exe", "ленин.exe", "малварь.exe", "сас.exe", "жопа.exe", "яндекс.exe", "я.exe", "Яндекс.exe", "Я.exe", "ВК.exe", "вк.exe", "Вк.exe", "вк_музыка.exe", "ВК_МУЗЫКА.exe", "лох.exe", "сука.exe", "невирус.exe", "НЕВИРУС.exe", "НеВирус.exe"," вагнер.exe", "петя.exe", "а4.exe", "А4.exe", "сатана.exe", "Сатана.exe", "САТАНА.exe", "негр.exe", "Негр.exe", "НЕГР.exe", "ЛОХ.exe", "Лох.exe", "еблан.exe", "Еблан.exe", "ЕБЛАН.exe", "Сталин.exe", "СТАЛИН.exe", "Ленин.exe", "ЛЕНИН.exe", "путин.exe", "Путин.exe", "ПУТИН.exe", "пизда.exe", "Пизда.exe", "ПИЗДА.exe", "хуйня.exe", "Хуйня.exe", "ХУЙНЯ.exe", "амогус.exe", "Амогус.exe", "АМОГУС.exe", "абобус.exe", "Абобус.exe", "АБОБУС.exe", "секс.exe", "Секс.exe", "СЕКС.exe", "писюн.exe", "Писюн.exe", "ПИСЮН.exe", "бебра.exe", "Бебра.exe", "БЕБРА.exe", "хуй.exe", "Хуй.exe", "ХУЙ.exe", "абаюдна.exe", "обоюдно.exe", "абидно.exe", "абоюдно.exe", "venom.exe", "веном.exe"]
#Стандартная Максимальная База Исключений
exceptions_proc = ["System Idle Process", "System.exe", "dwm.exe", "Taskmgr.exe", "mmc.exe", "perfmon.exe", "cmd.exe", "conhost.exe", "pio", "GPU", "explorer.exe", "LP.exe", "smss.exe", "Memory Compression", "Interrupts", "Interrupts", "Registry", "csrss.exe", "wininit.exe", "services.exe", "RuntimeBroker.exe", "InputPersonalization.exe", "ApplicationFrameHost.exe", "WindowsInternal.ComposableShell.Experiences.TextInput.InputApp.exe", "taskhostw.exe", "sihost.exe", "audiodg.exe", "spoolsv.exe", "ctfmon.exe", "SearchIndexer.exe", "SearchFilterHost.exe", "SearchProtocolHost.exe", "SearchProtocolHost.exe", "dllhost.exe", "lsass.exe", "fontdrvhost.exe", "csrss.exe", "winlogon.exe", "fontdrvhost.exe", "powershell.exe", "TiWorker.exe", "regedit.exe", "MsMpEng.exe"]
#Минимальная База Исключения
#exceptions_proc = ["System Idle Process", "System.exe", "dwm.exe", "Taskmgr.exe", "mmc.exe", "perfmon.exe", "cmd.exe", "conhost.exe", "pio", "GPU", "explorer.exe", "LP.exe", "regedit.exe"]
#Расширенная база исключений
#exceptions_proc = ["System Idle Process", "System.exe", "dwm.exe", "Taskmgr.exe", "mmc.exe", "perfmon.exe", "cmd.exe", "conhost.exe", "pio", "GPU", "explorer.exe", "LP.exe", "smss.exe", "Memory Compression", "Interrupts", "Interrupts", "Registry", "csrss.exe", "wininit.exe", "services.exe", "RuntimeBroker.exe", "InputPersonalization.exe", "ApplicationFrameHost.exe", "WindowsInternal.ComposableShell.Experiences.TextInput.InputApp.exe", "taskhostw.exe", "sihost.exe", "audiodg.exe", "spoolsv.exe", "ctfmon.exe", "SearchIndexer.exe", "SearchFilterHost.exe", "SearchProtocolHost.exe", "SearchProtocolHost.exe", "dllhost.exe", "lsass.exe", "fontdrvhost.exe", "csrss.exe", "winlogon.exe", "fontdrvhost.exe", "chrome.exe", "firefox.exe", "Telegram.exe", "memreduct.exe", "sublime_text.exe", "crash_handler.exe", "plugin_host-3.3.exe", "plugin_host-3.8.exe", "mpv.exe", "LightBulb.exe", "RtkAudUService64.exe", "pythonw.exe", "pythonw.exe", "ProcessHacker.exe", "recorder.exe", "uservice.exe", "UninstallTool.exe", "UninstallToolHelper.exe", "powershell.exe", "Win-RARA.exe", "Everything.exe", "Uninstall.exe", "krita.exe", "python.exe", "qbittorrent.exe", "Dism++x64.exe", "7zFM.exe", "HDSentinel.exe", "HDSCtrl.exe", "HDSAction.exe", "HDSentinelTray.exe", "harddisksentinelupdate.exe", "ACCICONS.EXE", "EXCEL.EXE", "GROOVE.EXE", "INFOPATH.EXE", "GRAPH.EXE", "misc.exe", "MSACCESS.EXE", "MSPUB.EXE", "OIS.EXE", "ONENOTE.EXE", "ONENOTEM.EXE", "OUTLOOK.EXE", "POWERPNT.EXE", "PPTICO.EXE", "protocolhandler.exe", "WINWORD.EXE", "WORDICON.EXE", "XLICONS.EXE", "maintenanceservice.exe", "TakeOwnershipEx.exe", "UltraISO.exe", "unins000.exe", "wmplayer.exe", "updater.exe", "regedit.exe", "py.exe", "pyw.exe", "Defrag.exe", "UserAccountControlSettings.exe", "control.exe", "write.exe", "regedt32.exe", "resmon.exe", "Unlocker.exe", "uninst.exe", "VirtualBox.exe", "blender.exe", "blender-launcher.exe"]