#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
from tkinter import messagebox
#Логирование Ошибок
from loguru import logger
from datetime import datetime
import tkinter as tk
from config import *
import subprocess
import random
import os

from RS import Random_String

global Run_log_txt, random_string, user_name
random_string = ""
run_version = "0.9.4 Beta"

@logger.catch
def Run():
    try:
        @logger.catch
        def Start_File_With_Admin(path):
            PO = 1
            if path == "C:\\Windows\\System32\\gpedit.msc":
                os.startfile(path)
                PO = 0
            if path == "C:\\Windows\\regedit.exe":
                os.startfile(path)
                PO = 0
            if PO == 1:
                try:
                    #Получаем имя текущего пользователя
                    username = os.getlogin()
                    print(f"Имя текущего пользователя: {username}")
                except Exception as e:
                    username = user_name
                    print("Не Удалось узнать имя пользователя!")

                #Проверяем Существует ли файл
                if os.path.exists(path):
                    try:
                        #Запускаем Файлик от имени администратора
                        subprocess.run(["runas", f"/user:{username}", path])
                    except Exception as e:
                        logger.error(f"Ошибка при запуске файла {path}\n{str(e)}")
                else:
                    logger.error(f"Ошибка не найден файл для запуска!\n{str(e)}")

        def Set_Path(path):
            entry.delete(0, tk.END)
            entry.insert(0, path)

        def On_OK():
            path = entry.get()
            Start_File_With_Admin(path)

        run = tk.Tk()
        run.focus_force()
        random_string = Random_String()
        run.title(random_string)
        run.geometry("350x150")
        run.configure(bg="#2E2E2E")

        entry = tk.Entry(run, width=50)
        entry.pack(pady=10)

        ok_button = tk.Button(run, text="ОК", command=On_OK, bg="#444444", fg="white")
        ok_button.pack(pady=10)

        buttons_frame = tk.Frame(run, bg="#2E2E2E")
        buttons_frame.pack(pady=10)

        buttons = {
            "CMD": "C:\\Windows\\System32\\cmd.exe",
            "REGEDIT": "C:\\Windows\\regedit.exe",
            "GPEDIT": "C:\\Windows\\System32\\gpedit.msc",
            "POWERSHELL": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            "EXPLORER": "C:\\Windows\\explorer.exe"
        }

        for text, path in buttons.items():
            button = tk.Button(buttons_frame, text=text, command=lambda p=path: Set_Path(p), bg="#444444", fg="white")
            button.pack(side=tk.LEFT, padx=5)

        run.bind("<Return>", lambda event: on_ok())
        run.mainloop()

    except Exception as e:
        logger.error(f"в Компоненте Run произошла неизвестаня ошибка!\n{str(e)}")