﻿#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
from tkinter import ttk, messagebox, Menu, simpledialog, filedialog
#Логирование Ошибок
from loguru import logger
from datetime import datetime
import tkinter as tk
import subprocess
import getpass
import random
import string
import shutil
import os

from Run import Run
from OF import Open_With
from RS import Random_String
from config import *

#Глобальные Переменные
global version_file_manager, user_name, loging, E_log_txt, settings_path, message_txt, loging_txt, random_string
file_manager_version = "3.5.10 Alpha"
random_string = ""

@logger.catch
def E():
    try:
        def Load_Settings():
            global message
            if not os.path.exists(settings_path):
                os.makedirs(settings_path)
                with open(f"{settings_path}\\{message_txt}", "w") as file:
                    file.write("False")
                print(f"Файл {settings_path}\\{message_txt} создан со значением False")
            if not os.path.isfile(f"{settings_path}\\{message_txt}"):
                with open(f"{settings_path}\\{message_txt}", "w") as file:
                    file.write("False")
                print(f"Файл {settings_path}\\{message_txt} создан со значением False")
            with open(f"{settings_path}\\{message_txt}", "r") as file:
                message = file.read()
            if message == "True":
                print("1-ая праверка переменной message пройдена")
                mepr = 1
            if message == "False":
                print("2-ая проверка переменной message пройдена")
                mepr = 1
            if mepr == 0:
                message = "False"
                with open(f"{settings_path}\\{message_txt}", "w") as file:
                    file.write("False")
                print(f"Файл {settings_path}\\{message_txt} создан со значением False")

        Load_Settings()

        #Чтение Имя текущего пользователя
        try:
            user_name = getpass.getuser()
            print(f"Имя Текущего Пользователя: {user_name}")
        except Exception as e:
            logger.error(f"Ошибка получения имени пользователя!\n{str(e)}")

        #Сохранение Настроек
        def Save_Settings(message):
            with open(f"{settings_path}\\{message_txt}", "w") as f:
                f.write(message)

        #Получение Информации о файле
        def Get_Files_Info(path):
            try:
                files_info = []
                for i, file in enumerate(os.listdir(path), start=1):
                    file_path = os.path.join(path, file)
                    file_stat = os.stat(file_path)
                    size_bytes = file_stat.st_size
                    
                    # Проверка на допустимость времени создания
                    try:
                        create_time = datetime.fromtimestamp(file_stat.st_ctime)
                    except OSError as e:
                        logger.error(f"Ошибка при получении даты и времени создания файла. В функции Get_Files_Info!\n{str(e)}")
                        create_time = "Неизвестно"

                    files_info.append((i, file, size_bytes, create_time, file_path))
                return files_info
            except Exception as e:
                logger.error(f"Ошибка при получении информации - {path}\n{str(e)}")
                return ["Ошибка при получении информации"]

        #Кнопка |->
        def Update_File_List(path, index):
            files_info = Get_Files_Info(path)
            tree[index].delete(*tree[index].get_children())
            for file_info in files_info:
                size = file_info[2]
                size_unit = Get_Formatted_Size(size)
                file_data = list(file_info)
                file_data[2] = size_unit
                #file_data[3] = file_data[3].strftime("%d-%m-%Y %H:%M:%S")
                tree[index].insert("", "end", values=file_data)

            tabs_state[index].current_path = path
            current_path_var.set(path)

        def Get_Available_Drives():
            drives = []
            for drive in string.ascii_uppercase:
                if os.path.exists(drive + ":\\"):
                    drives.append(drive)
            return drives

        #Перевод Веса файла в нужный формат
        def Get_Formatted_Size(size):
            if not isinstance(size, (int, float)):
                return "Ошибка: размер не является числом"
            
            units = ["Байт", "КБ", "МБ", "ГБ", "ТБ"]
            unit_index = 0
            while size >= 1024 and unit_index < len(units) - 1:
                size /= 1024.0
                unit_index += 1
            return f"{size:.2f} {units[unit_index]}"


        #Обновление Пути
        def Handle_Text_Input(event):
            path = current_path_var.get()
            if os.path.exists(path):
                Update_File_List(path, 0)
            #else:
                #random_string = Random_String()
                #messagebox.showerror(random_string, "Указанный путь не существует.")

        #Обновление Текста в текстовом поле для текущей вкладки
        def Update_Current_Path_Text(index):
            current_path = tabs_state[index].current_path
            current_path_var.set(current_path) #Обновляем текстовое поле
            Handle_Text_Input(index)

        #Открытие Настроек
        def E_Settings():
            settings_window = tk.Toplevel()
            random_string = Random_String()
            settings_window.title(random_string)

            setting_var_1 = tk.BooleanVar(value=(message == "True"))
            ttk.Checkbutton(settings_window, text="Показывать сообщения при действиях", variable=setting_var_1).pack()

            apply_button = ttk.Button(settings_window, text="Применить", command=lambda: Apply_Settings(setting_var_1.get()))
            apply_button.pack(pady=10)

        #Сохранение Настроек
        def Apply_Settings(setting1):
            global message
            message = str(setting1)
            Save_Settings(message)

        #О Программе
        def About():
            random_string = Random_String()
            messagebox.showinfo(random_string, f"Файловый Менеджер {file_manager_version}\nCreated by NEON Life\nPowered by Departament K\nCoded by @AnonimNEO\nCopyright (c) NEON Life 2024 - 2025")

        E = tk.Tk()
        E.focus_force()
        #Создаём Тему
        style = ttk.Style()
        style.theme_use("clam")

        class TabState:
            def __init__(self):
                self.history = []
                self.forward_history = []
                self.current_path = ""
                self.copied_cut_path = None

        tabs_state = []

        #Двойное Нажатие
        def On_Item_Double_Click(event, index):
            item = tree[index].focus()
            file_path = tree[index].item(item, "values")[-1]
            if os.path.isdir(file_path):
                tabs_state[index].history.append(tabs_state[index].current_path)
                tabs_state[index].forward_history.clear()
                Update_File_List(file_path, index)
            elif os.path.isfile(file_path):
                try:
                    os.startfile(file_path)
                except Exception as e:
                    logger.error(f"Не удалось открыть файл: {file_path}\n{str(e)}")
                    random_string = Random_String()
                    messagebox.showerror(random_string, f"Не удалось открыть файл:\n{str(e)}")

        #Кнопка <-
        def Go_Back(index):
            if tabs_state[index].history:
                previous_path = tabs_state[index].history.pop()
                tabs_state[index].forward_history.append(tabs_state[index].current_path)
                Update_File_List(previous_path, index)

        #Кнопка ->
        def Go_Forward(index):
            if tabs_state[index].forward_history:
                next_path = tabs_state[index].forward_history.pop()
                tabs_state[index].history.append(tabs_state[index].current_path)
                Update_File_List(next_path, index)



        #Окно Свойств файла
        def Open_File_Properties(file_path):
            if os.path.isfile(file_path):
                try:
                    file_stat = os.stat(file_path)
                    size = file_stat.st_size
                    
                    #Проверка на допустимость времени создания
                    try:
                        create_time = datetime.fromtimestamp(file_stat.st_ctime)
                    except OSError:
                        logger.error(f"Ошибка при получении даты и времени создания файла. В функции Open_File_Properties.\n{str(e)}")
                        create_time = "Неизвестно"
                    
                    modify_time = datetime.fromtimestamp(file_stat.st_mtime)
                    access_time = datetime.fromtimestamp(file_stat.st_atime)

                    properties_window = tk.Toplevel(E)
                    random_string = Random_String()
                    properties_window.title(random_string)

                    tab_control = ttk.Notebook(properties_window)
                    tab_control.pack(expand=1, fill="both")

                    main_tab = ttk.Frame(tab_control)
                    detailed_tab = ttk.Frame(tab_control)

                    tab_control.add(main_tab, text="Основное")
                    tab_control.add(detailed_tab, text="Подробно")

                    ttk.Label(main_tab, text=f"Имя файла: {os.path.basename(file_path)}").pack()
                    ttk.Label(main_tab, text=f"Вес файла: {Get_Formatted_Size(size)}").pack()
                    ttk.Label(main_tab, text=f"Дата создания: {create_time}").pack()
                    ttk.Label(main_tab, text=f"Дата изменения: {modify_time}").pack()
                    ttk.Label(main_tab, text=f"Дата последнего открытия: {access_time}").pack()
                    ttk.Label(detailed_tab, text=f"Чтение: {"Да" if os.access(file_path, os.R_OK) else "Нет"}").pack()
                    ttk.Label(detailed_tab, text=f"Запись: {"Да" if os.access(file_path, os.W_OK) else "Нет"}").pack()
                    ttk.Label(detailed_tab, text=f"Исполнение: {"Да" if os.access(file_path, os.X_OK) else "Нет"}").pack()
                except Exception as e:
                    random_string = Random_String()
                    messagebox.showerror(random_string, f"Не удалось получить свойства файла:\n{str(e)}")
            else:
                random_string = Random_String()
                messagebox.showerror(random_string, "Выбранный путь не является файлом.")




        #Выбора диска
        def Create_Drive_Menu(tab, index):
            drive_label = ttk.Label(tab, text="Выберите диск:")
            drive_label.pack()

            drive_combo = ttk.Combobox(tab)
            drive_combo.pack()

            drives = Get_Available_Drives()
            
            drive_combo["values"] = drives

            def on_drive_select(event):
                try:
                    drive = drive_combo.get()
                    if drive:  # Проверяем, что диск выбран
                        drive_path = f"{drive}:\\"  # Формируем путь к диску
                        if os.path.exists(drive_path):  # Проверяем существует ли путь
                            tabs_state[index].history.clear()
                            tabs_state[index].forward_history.clear()
                            Update_File_List(drive_path, index)
                        else:
                            logger.error(f"Диск {drive} не доступен.")
                            random_string = Random_String()
                            messagebox.showerror(random_string, f"Диск {drive} не доступен.")
                except PermissionError:
                    logger.error(f"Нет доступа к диску {drive}.")
                    random_string = Random_String()
                    messagebox.showerror(random_string, f"Нет доступа к диску {drive}.")
                except Exception as e:
                    logger.error(f"Ошибка при выборе диска {drive}: {str(e)}")
                    random_string = Random_String()
                    messagebox.showerror(random_string, f"Ошибка при выборе диска {drive}:\n{str(e)}")


            drive_combo.bind("<<ComboboxSelected>>", on_drive_select)

            tree.append(ttk.Treeview(tab, columns=("Number", "Name", "Size", "Created")))
            tree[index].heading("#0", text="")
            tree[index].column("#0", width=0, stretch=False)
            tree[index].heading("Number", text="№")
            tree[index].column("Number", width=50, stretch=False)
            tree[index].heading("Name", text="Имя файла")
            tree[index].heading("Size", text="Размер файла")
            tree[index].heading("Created", text="Дата создания")
            tree[index].pack(expand=True, fill=tk.BOTH)
            tree[index].bind("<Double-1>", lambda event, idx=index: On_Item_Double_Click(event, idx))

            #Создание контекстного меню
            tree[index].bind("<Button-3>", lambda event, idx=index: Show_Context_Menu(event, idx))

            tabs_state.append(TabState())




        #Обновление списка файлов
        def Refresh_File_List():
            current_path = tabs_state[0].current_path
            if os.path.exists(current_path):
                Update_File_List(current_path, 0)
            else:
                random_string = Random_String()
                messagebox.showerror(random_string, "Указанный путь не существует.")

        #Поднятия Вверх по древу каталогов
        def Go_Up():
            current_path = tabs_state[0].current_path
            parent_path = os.path.dirname(current_path)
            if parent_path and os.path.exists(parent_path):
                tabs_state[0].history.append(current_path)
                tabs_state[0].forward_history.clear()
                Update_File_List(parent_path, 0)
            else:
                random_string = Random_String()
                messagebox.showerror(random_string, "Не удалось подняться на уровень выше.")

        #Открытие Новой вкладки
        def Add_Tab():
            new_tab = ttk.Frame(notebook)
            notebook.add(new_tab, text="Диск")
            Create_Drive_Menu(new_tab, len(tabs_state))

            notebook.bind("<<NotebookTabChanged>>", On_Tab_Changed) #Привязываем Событие смены вкладки

        #Закрытия Текущей вкладки
        def Close_Current_Tab():
            if notebook.index("end") > 0: #Проверяем что есть еще открытые вкладки
                current_tab_index = notebook.index(notebook.select()) #Получаем Индекс текущей вкладки
                notebook.forget(current_tab_index) #Закрываем Текущую вкладку
                del tabs_state[current_tab_index] #Удаляем Состояние для текущей вкладки
                del tree[current_tab_index] #Удаляем Дерево для текущей вкладки
            else:
                logger.error(f"Закрыты все вкладки!\n{str(e)}")
                print("Нет открытых вкладок!")



        menu_bar = Menu(E)

        #Пункты в верхней панели
        menu_bar.add_command(label="Открыть", command=Run)
        menu_bar.add_command(label="Настройки", command=E_Settings)
        menu_bar.add_command(label="Открыть С Помошью", command=Open_With)
        menu_bar.add_command(label="О программе", command=About)

        E.config(menu=menu_bar)
        random_string = Random_String()
        E.title(random_string)

        #Кнопки
        frame_controls = tk.Frame(E)
        frame_controls.pack(side=tk.TOP, fill=tk.X)

        button_left = tk.Button(frame_controls, text="<-", width=5, command=lambda: Go_Back(0))
        button_left.pack(side=tk.LEFT)

        button_right = tk.Button(frame_controls, text="->", width=5, command=lambda: Go_Forward(0))
        button_right.pack(side=tk.LEFT)

        button_vertical = tk.Button(frame_controls, text="|", width=5, command=Go_Up)
        button_vertical.pack(side=tk.LEFT)

        button_refresh = tk.Button(frame_controls, text="|->", command=Refresh_File_List, width=5)
        button_refresh.pack(side=tk.LEFT)

        add_button = tk.Button(frame_controls, text=" + ", command=Add_Tab, font=("Arial", 12))
        add_button.pack(side=tk.LEFT)

        close_button = tk.Button(frame_controls, text=" - ", command=Close_Current_Tab, font=("Arial", 12))
        close_button.pack(side=tk.LEFT)

        current_path_var = tk.StringVar()
        current_path_entry = ttk.Entry(E, textvariable=current_path_var)
        current_path_entry.pack(side=tk.TOP, fill=tk.X)
        current_path_entry.bind("<Return>", Handle_Text_Input) #Обработка нажатия Enter

        notebook = ttk.Notebook(E)
        notebook.pack(expand=True, fill=tk.BOTH)

        tree = []

        #ПКМ
        def Show_Context_Menu(event, index):
            item = tree[index].identify_row(event.y)
            if item:
                tree[index].selection_set(item)
                context_menu.post(event.x_root, event.y_root)

        #Функция Копировать
        def Copy_File():
            item = tree[0].focus()
            if item: #Проверяем, что элемент выбран
                file_path = tree[0].item(item, "values")[-1] #Получаем путь к файлу
                tabs_state[0].copied_cut_path = file_path
                if message == "True":
                    random_string = Random_String()
                    messagebox.showinfo(random_string, "Файл скопирован.")
            else:
                random_string = Random_String()
                messagebox.showwarning(random_string, "Пожалуйста, выберите файл для копирования.")

        #Функция Вставить
        def Paste_File():
            if tabs_state[0].copied_cut_path:
                dest_path = tabs_state[0].current_path
                src_path = tabs_state[0].copied_cut_path
                dest_file = os.path.join(dest_path, os.path.basename(src_path))

                #Проверка на совпадение каталогов
                if os.path.dirname(src_path) == dest_path:
                    random_string = Random_String()
                    messagebox.showerror(random_string, "Нельзя вставить файл в тот же каталог.")
                    return

                if os.path.exists(dest_file):
                    random_string = Random_String()
                    if messagebox.askyesno(random_string, "Файл уже существует. Заменить его?"):
                        random_string = Random_String()
                        backup = messagebox.askyesno(random_string, "Создать резервную копию файла?")
                        if backup:
                            if not os.path.exists(os.path.join(dest_path, "backup")):
                                os.makedirs(os.path.join(dest_path, "backup"))
                            shutil.copy(dest_file, os.path.join(dest_path, "backup", os.path.basename(dest_file)))
                            print(dest_file, dest_path)
                        shutil.copy2(src_path, dest_file)
                        if message == "True":
                            random_string = Random_String()
                            messagebox.showinfo(random_string, "Файл заменен.")
                    else:
                        if message == "True":
                            random_string = Random_String()
                            messagebox.showinfo(random_string, "Операция отменена.")
                else:
                    shutil.copy2(src_path, dest_file)
                    if message == "True":
                        random_string = Random_String()
                        messagebox.showinfo(random_string, "Файл вставлен.")
            else:
                random_string = Random_String()
                messagebox.showerror(random_string, "Нет файла для вставки.")

        #Функция Переименовать
        def Rename_File():
            item = tree[0].focus()
            file_path = tree[0].item(item, "values")[-1]
            random_string = Random_String()
            new_name = simpledialog.askstring(random_string, "Введите новое имя файла:", initialvalue=os.path.basename(file_path))

            if new_name:
                new_path = os.path.join(os.path.dirname(file_path), new_name)
                if os.path.exists(new_path):
                    random_string = Random_String()
                    messagebox.showerror(random_string, "Файл с таким именем уже существует.")
                elif new_name == os.path.basename(file_path):
                    random_string = Random_String()
                    messagebox.showerror(random_string, "Новое имя файла не должно совпадать со старым.")
                else:
                    os.rename(file_path, new_path)
                    Refresh_File_List()
                    if message == "True":
                        random_string = Random_String()
                        messagebox.showinfo(random_string, "Файл переименован.")

        #Функция Удалить
        def Delete_File():
            item = tree[0].focus()
            file_path = tree[0].item(item, "values")[-1]
            random_string = Random_String()
            if messagebox.askyesno(random_string, "Вы уверены, что хотите удалить файл?"):
                try:
                    os.remove(file_path)
                    Refresh_File_List()
                    if message == "True":
                        random_string = Random_String()
                        messagebox.showinfo(random_string, "Файл удалён.")
                except Exception as e:
                    logger.error(f"Ошибка при удалении файла!\n{str(e)}")
                    random_string = Random_String()
                    messagebox.showerror(random_string, f"Ошибка при удалении файла:\nstr(e)")

        #Запуск Файла от имени администратора
        def Run_As_Admin():
            item = tree[0].focus()
            file_path = tree[0].item(item, "values")[-1]
            try:
                subprocess.run(f"runas /user:{user_name} \"{file_path}\"", shell=True, check=True)
            except subprocess.CalledProcessError as e:
                logger.add(f"Не удалось запустить файл от имени администратора {file_path}")
                Random_String()
                messagebox.showerror(random_string, f"Не удалось запустить файл от имени администратора:\n{str(e)}")

        #Обновление Вкладок и пути
        def On_Tab_Changed(event):
            current_tab_index = notebook.index(notebook.select()) #Получаем Индекс текущей вкладки
            Update_Current_Path_Text(current_tab_index)

        #Контекстное меню
        context_menu = Menu(E, tearoff=0)
        context_menu.add_command(label="Копировать", command=Copy_File)
        context_menu.add_command(label="Вставить", command=Paste_File)
        context_menu.add_separator()
        context_menu.add_command(label="Переименовать", command=Rename_File)
        context_menu.add_command(label="Удалить", command=Delete_File)
        context_menu.add_command(label="Свойства", command=lambda: Open_File_Properties(tree[0].item(tree[0].focus(), "values")[-1] if tree[0].focus() else None))
        context_menu.add_separator()
        context_menu.add_command(label="Запустить от имени администратора", command=Run_As_Admin)

        Add_Tab() #Добавляем Первую вкладку

        current_path_var.set(tabs_state[0].current_path)

        E.mainloop()

    except Exception as e:
        logger.error(f"Произошла неизвестаня ошибка в Компоненте AutoRunMaster!\n{str(e)}")