from tkinter import messagebox, filedialog
from datetime import datetime
import win32com.client
import winreg as reg
import tkinter as tk
import subprocess
import platform
import zipfile
import shutil
import sys
import os

from LE import Loging_Error
global MU_zip_file, comment, folder_to_setup, version_setup, e, T_path
MU_zip_file = "MU.zip"
version_setup = "0.5 Alpha build 3"
folder_to_setup = ""

try:
    #Добавляем T в Автозагрузку
    def T_in_run(T_path):
        try:
            #print(folder_to_setup)
            #T_path = folder_to_setup + "\T.exe"
            #Открываем ключ реестра для редактирования
            registry_key = reg.OpenKey(reg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\", 0, reg.KEY_WRITE)

            # Заменяем значение
            reg.SetValueEx(registry_key, "Userinit", 0, reg.REG_SZ, rf"C:\Windows\System32\userinit.exe, {T_path}")

            #Закрываем ключ реестра
            reg.CloseKey(registry_key)
            print(f"Значение Userinit успешно изменено на C:\\Windows\\System32\\userinit.exe, {T_path}")

        except PermissionError:
            print("Необходимы права администратора для изменения реестра.")
        except Exception as e:
            print(f"Произошла ошибка: {str(e)}")
            Loging_Error("Ошибка при довалении программы в автозапуск", "Setup_log.txt", str(e))

        messagebox.showinfo("Установка Завершена!", "Установка выполнена успешно(но это не точно)\nПРЕДУПРЕЖДЕНИЕ! \nПрограмма находится в Pre-Alpha Тестировании!\nПРЕДУПРЕЖДЕНИЕ 2!\nПрограмма была добавлена в автозагрузку через реестр в параемтр usernit!\nПРЕДУПРЕЖДЕНИЕ 3!\nНЕ Запускайте программу через ярлык, иначе программа будет думать что она запущена через каталог в котором находится ярлык!\n\nБлагодарим за установку даного ПО!")



    def Copy_Data(T_path):
        if not os.path.exists("data"):
            comment = "Папка 'data' не существует!"
            print(comment)
            Loging_Error(comment, "Setup_log.txt", str(e))
            messagebox.showerror("Файлы Установки Повредены!", "Каталог 'data' не существует в директории установки!\nУстановка дальше не возмжна.\nРаспакуйте архив с официального сайта ещё раз.")
        else:
            #Получаем список файлов в исходном каталоге
            files = os.listdir("data")
            
            #Копируем каждый файл в целевой каталог
            for file_name in files:
                source_file = os.path.join("data", file_name)
                destination_file = os.path.join("C:\\Windows\\Media", file_name)
                
                #Проверяем, является ли это файлом (а не каталогом)
                if os.path.isfile(source_file):
                    shutil.copy2(source_file, destination_file) #сохраняет метаданные
                    print(f"Файл: {file_name} скопирован")
                else:
                    print(f"Пропущено (не файл): {file_name}")

        T_in_run(T_path)



    #Создание Ярлыка
    def Create_Shortcut(target, shortcut_name, T_path):
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        shortcut_path = os.path.join(desktop, f"{shortcut_name}.lnk")

        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(shortcut_path)
        shortcut.TargetPath = target
        shortcut.IconLocation = target
        shortcut.save()

        print("Ярлык Создан!")
        Copy_Data(T_path)



    #Окно Установки
    def Setup_Window():
        def Install_Python_32():
            os.startfile("python-3.12.0-amd32.exe")
        def Install_Python_64():
            os.startfile("python-3.12.0-amd64.exe")

        window = tk.Tk()
        window.title("Установка Python")
        window.geometry("600x325")

        #Текст инструкции
        message = ("Для установки вам потребуется установить Python 3.12, если у вас уже установлена эта или версия выше,\nнажмите кнопку 'Установить библиотеки', если у вас версия ниже, не отчаивайтесь, попробуйте установить так,\n(главное, чтобы была версия 3, а не 2). Если у вас не установлен Python,\nто нажмите на кнопку 'Установить Python 3.12.0 x64' или 'Установить Python 3.12.0 x32'\nЕсли у вас установлены нужные библиотеки то пропустите их установку\n(но при ошибках обновите их через кнопку 'Установить библиотеки'')")
        label = tk.Label(window, text=message, wraplength=500, justify="left")
        label.pack(pady=20)
        
        btn_install_python32 = tk.Button(window, text="Установить Python 3.12.0 x32", command=Install_Python_32)
        btn_install_python32.pack(pady=5)

        btn_install_python64 = tk.Button(window, text="Установить Python 3.12.0 x64", command=Install_Python_64)
        btn_install_python64.pack(pady=5)

        def Install_Library():
            os.startfile("Install_Library.bat")

        btn_list_libs = tk.Button(window, text="Установить библиотеки", command=Install_Library)
        btn_list_libs.pack(pady=5)

        #Кнопка для компиляции
        def Start_Compilation():
            try:
                with zipfile.ZipFile(MU_zip_file, "r") as zip_ref:
                    #Распаковка Архива в Указанную Папку
                    zip_ref.extractall("")
                    print(f"Архив {MU_zip_file} успешно распакован в каталог установки")
            except Exception as e:
                print(f"Ошибка при запуске файла {MU_zip_file}: {e}")
            compilation_window = tk.Toplevel(window)
            compilation_window.title("Компиляция")
            label = tk.Label(compilation_window, text="0)ОТРЕДАКТИРУЙТЕ ФАЙЛ confing.py, (выберите желательные параметры) 1)Откройте командную строку\n2)Скопируйте путь к каталогу в котором запущен установщщик\nвставте в консоль : 'cd  [ПУТЬ_К_КАТАЛОГ]', нажмите Enter\n3)если этот каталог расположен на любом диске кроме C: то введите в консоль следуещее : '[БУКВА ДИСКА] :', Enter\n4)введите в консоль это : 'pyinstaller -F -w -i 'icon\LP_icon.ico' LP.py', \nпосле завершения отредактируйте код в файле T.py, а именно переменую LP_size замените её значения на вес файла LP.exe в байтах\n(СКОПИРУЙТЕ ЗАНЧЕНИЕ НА ПРОТИВ ТЕКСТА 'Размер'), \nпосле сохранеия, введите в консоль это : 'pyinstaller -F -w -i 'icon\T_icon.ico' T.py', после окночания нажмите 'Завершить Установку'")
            label.pack(pady=20)



            #Последний этап Установки
            def finish_compilation():
                compilation_window.withdraw()
                folder_to_setup = filedialog.askdirectory(title="Выберите каталог для установки")
                try:
                    #Копируем все файлы из папки dist в указанную папку
                    for item in os.listdir("dist\\"):
                        source_path = os.path.join("dist\\", item)
                        destination_path = os.path.join(folder_to_setup, item)
                        
                        if os.path.isfile(source_path):
                            shutil.copy2(source_path, destination_path) #Копируем файлы
                        elif os.path.isdir(source_path):
                            shutil.copytree(source_path, destination_path) #Копируем подкаталоги

                    T_path = folder_to_setup + "\T.exe"
                    Create_Shortcut(T_path, "Зауск Антивирус Монтировка", T_path)
                    messagebox.showinfo("Завершение", "Установка завершена!")

                except Exception as e:
                    comment = "Ошибка на последнем этапе установки"
                    Loging_Error(comment, "Setup_log.txt", str(e))
                    messagebox.showerror("Ошибка", f"Произошла ошибка: {str(e)}")

            btn_finish = tk.Button(compilation_window, text="Завершить установку", command=finish_compilation)
            btn_finish.pack(pady=5)

        btn_compile = tk.Button(window, text="Начать компиляцию", command=Start_Compilation)
        btn_compile.pack(pady=5)

        window.mainloop()

    if __name__ == "__main__":
       Setup_Window()



except Exception as e:
    comment = "Произошла не известаная ошибка в программе установки!"
    Loging_Error(comment, "Setup_log.txt", str(e))