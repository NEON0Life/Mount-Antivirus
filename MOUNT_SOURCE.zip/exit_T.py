#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
from tkinter import messagebox, simpledialog
import tkinter as tk
import string
import random
import os

from RS import Random_String
from LE import Loging_Error
from confing import *

exit_version = "1.0 Beta"

global exit_T_log_txt, Random_String, random_string
random_string = ""

#Путь к файлу
dyrachok_path = "C:\\ProgramData\\dyrachok.txt"

try:
    def Check_File():
        if not os.path.exists(dyrachok_path):
            with open(dyrachok_path, "w") as f:
                pass
        else:
            with open(dyrachok_path, "r") as f:
                content = f.read()
                if "debil" in content:
                    random_string = Random_String()
                    messagebox.showwarning(random_string, "Вы смотрите тикток!\nПрограмма не будет закрыта.")
                    return False
        return True



    def tiktok_Question():
        random_string = Random_String()
        if messagebox.askyesno(random_string, "Смотрити ли вы тикток?"):
            with open(dyrachok_path, "w") as f:
                f.write("debil")
            random_string = Random_String()
            messagebox.showinfo(random_string, "Вы смотрите тикток!\nПрограмма не будет закрыта.")
        else:
            print("Завершение Программы...")
            exit()



    def Math_Window():
        random_string = Random_String()
        n = random.randint(256, 1024)
        number_input = tk.simpledialog.askinteger(random_string, f"Введите результат данного примера: √{n} * {n}")

        if number_input == n:
            tiktok_Question()
        else:
            random_string = Random_String()
            messagebox.showerror(random_string, "Неправильный ввод капчи.\nПрограмма не будет закрыта.")



    def Captcha_Window():
        random_string = Random_String()
        n = random.randint(256, 1024)
        captcha_input = tk.simpledialog.askinteger(random_string, f"Введите число: {n}")

        if captcha_input == n:
            Math_Window()
        else:
            random_string = Random_String()
            messagebox.showerror(random_string, "Неправильный ввод капчи.\nПрограмма не будет закрыта.")



    def Ask_Exit():
        if Check_File():
            random_string = Random_String()
            if messagebox.askyesno(random_string, "Вы действительно хотите выйти из данного програмного обеспечения?"):
                Captcha_Window()
            else:
                random_string = Random_String()
                messagebox.showerror(random_string, "Данное програмное обеспечение не будет закрыто.")



except Exception as e:
    comment = "Неизвестная ошибочка в компоненте exit_T!"
    print(comment)
    print(str(e))
    Loging_Error(comment, exit_T_log_txt, str(e))