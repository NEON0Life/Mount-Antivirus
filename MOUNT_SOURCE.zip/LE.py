#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
from datetime import datetime
from confing import *
import os

global settings_path, loging_txt, log_path

loging_error_version = "0.4"

def Loging_Error(comment, log_name, e):
    #Записываем ошибку и время в лог файл
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    if not os.path.exists(f"{log_path}\\{log_name}"):
        #Если файл не существует, создаем его
        error_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        with open(f"{log_path}\\{log_name}", "w") as file:
            file.write(f"Этот лог файл был создан в {error_time}")
        print(f"Файл {log_path}\\{log_name} был создан")
    #Получаем текущее время и дату
    error_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    with open(f"{log_path}\\{log_name}", "a") as file:
        file.write(f"\n{error_time} Ошибка: {str(e)}, {comment}")
    return

def Read_loging_txt():
    try:
        lopr = 0
        if not os.path.exists(settings_path):
            os.makedirs(settings_path)
            with open(f"{settings_path}\\{loging_txt}", "w") as file:
                file.write("1")
        if not os.path.isfile(f"{settings_path}\\{loging_txt}"):
            with open(f"{settings_path}\\{loging_txt}", "w") as file:
                file.write("1")
        with open(f"{settings_path}\\{loging_txt}", 'r') as file:
            loging = file.read().strip()
        if loging == "0":
            lopr = 1
            print("1-ая проверка переменной loging пройдена")
        if loging == "1":
            lopr = 1
            print("2-ая проверка переменной loging пройдена")
        if lopr == 0:
            loging = 1
            with open(f"{settings_path}\\{loging_txt}", "w") as file:
                file.write("1")
            print(f"файл {settings_path}\\{loging_txt} создан со значением 1")
    except FileNotFoundError:
        loging = "1"
        return loging