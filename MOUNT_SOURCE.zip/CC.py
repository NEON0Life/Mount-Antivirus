#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
import datetime
import getpass
import shutil
import os

from LE import Loging_Error
from confing import *

global CC_log_txt, clear_temp_log, log_path, clear_temp_log

clear_cache_version = "0.6 Beta"

def CC():
    try:
        def Clean_Temp():
            print("Очитска Запущена")
            #Получаем имя пользователя
            username = getpass.getuser()
            temp_dir = f"C:\\Users\\{username}\\AppData\\Local\\Temp"

            #Переменные для логирования
            files_not_deleted = []
            files_deleted = []

            try:
                #Проходим по содержимому папки Temp
                for item in os.listdir(temp_dir):
                    item_path = os.path.join(temp_dir, item)
                    try:
                        if os.path.isfile(item_path):
                            os.remove(item_path)
                            files_deleted.append(item)
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)
                            files_deleted.append(item)
                    except Exception as e:
                        files_not_deleted.append(item)

                #Получаем текущее время и дату для имени лог-файла
                current_time = datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
                log_filename = f"{log_path}\\{clear_temp_log}_{current_time}.txt"
                if not os.path.exists(log_path):
                    os.makedirs(log_path)
                with open(log_filename, "w") as log_file:
                    log_file.write("Ошибка при удалении следующих файлов:\n")
                    for file in files_not_deleted:
                        log_file.write(f"{file}\n")
                    log_file.write("\nУспешно удалёные файлы:\n")
                    for file in files_deleted:
                        log_file.write(f"{file}\n")

                print(f"Лог файл {log_path}\\'{log_filename}' был создан.")
            except Exception as e:
                print(f"Произошла ошибка: {e}")
                Loging_Error("В ClearCache произошла неизвестаная ошибка", CC_log_txt, str(e))

        Clean_Temp()

    except Exception as e:
        Loging_Error("В ClearCache произошла неизвестаная ошибка", CC_log_txt, str(e))