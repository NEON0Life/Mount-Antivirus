#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
#Рисование иконки в трее и вставка картинок
from PIL import Image, ImageDraw, ImageFont, ImageTk
#Графический Интерфейс
from tkinter import messagebox, filedialog
from tkinter import ttk
import tkinter as tk
#Движок иконки в трее
#Дата и Время
from datetime import datetime
#Получение прав Администратора
#Обращение к веб-браузеру
import webbrowser
#Вроде как оптимизация
#Генерация Текста
import random
#Обращение к Системным Командам и Значениям
import sys
import os

#Импорт Компонентов
from confing import *
from CC22 import CC22
from RS import Random_String
from LE import Loging_Error, Read_loging_txt

global trey_version, run_version, autorun_master_version, clear_cache_versionm, file_manager_version, exit_version, loging_error_version, load_protection_version, unlocker_version, other_komponents_version, restart_version, random_string_version, clear_cache_version, load_protection_version, about_program_version
about_program_version = "0.2 beta"

def About_Program():
    class ImageLoaderApp:
        def __init__(self, about_window):
            self.about_window = about_window
            random_string = Random_String()
            self.about_window.title(random_string)
            self.about_window.configure(bg="black")

            #Текст
            self.label = tk.Label(about_window, text=f"Антивирус Монтировка\nВытащит любой гвоздь из крышки гроба вашего ПК!(как минимум попытается)\nCreated by NEON Life\nPowered by Departament K\nCoded by @AnonimNEO, Всего строчек кода : {all_line}\nПрограмисты/Задумщики/Художники/Тестировщики : @AnonimNEO\nЛицензии:\nАнтивирус Монтировка GPL v3.0 Copyleft (>) 2024 - 2025\n", bg="black", fg="white", font=("ComicSans", 16))

            self.label.pack(pady=20)

            #Полоска Картинок
            self.image_frame = tk.Frame(about_window, bg="black")
            self.image_frame.pack(pady=20)

            self.image_labels = []
            self.load_images()

            #Ссылки
            self.licenselink = tk.Label(about_window, text="Лицензионное Соглашение", bg="black", fg="red", cursor="hand2", font=("ComicSans", 16))
            self.licenselink.pack(pady=10)
            self.licenselink.bind("<Button-1>", self.open_license_policy)

            self.versionlink = tk.Label(about_window, text="Версии Компонентов", bg="black", fg="green", cursor="hand2", font=("ComicSans", 16))
            self.versionlink.pack(pady=10)
            self.versionlink.bind("<Button-1>", self.konponent_version)

            self.donationalertslink = tk.Label(about_window, text="Поддержать нас можно перейдя по этой ссылке\nи заплатив на 2 банки сгущёнки", bg="black", fg="red", cursor="hand2", font=("ComicSans", 16))
            self.donationalertslink.pack(pady=10)
            self.donationalertslink.bind("<Button-1>", self.open_link)

            self.gpllink = tk.Label(about_window, text="Лицнзия GPL v3.0", bg="red", fg="black", cursor="hand2", font=("ComicSans", 16))
            self.gpllink.pack(pady=10)
            self.gpllink.bind("<Button-1>", self.open_link2)

            self.websitelink = tk.Label(about_window, text="Веб-Сайт NEON Life", bg="blue", fg="yellow", cursor="hand2", font=("ComicSans", 16))
            self.websitelink.pack(pady=10)
            self.websitelink.bind("<Button-1>", self.open_link3)

        #Добавляем все изображения из каталога
        def load_images(self):
            image_files = [f for f in os.listdir(images_path) if f.endswith((".png", ".jpg", ".jpeg", ".gif"))]

            if not image_files:
                self.label.config(text="Ошибка загрузки изображений.")
                return

            for image_file in image_files:
                img_path = os.path.join(images_path, image_file)
                img = Image.open(img_path)
                img_tk = ImageTk.PhotoImage(img)

                label = tk.Label(self.image_frame, image=img_tk, bg="black")
                label.image = img_tk
                label.pack(side=tk.LEFT, padx=5)
                self.image_labels.append(label)


        def open_license_policy(self, event):
            webbrowser.open("https://sites.google.com/view/license-agreement-neon-life/")
        def konponent_version(self, event):
            random_string = Random_String()
            messagebox.showinfo(random_string, f"Версии Компонентов (данные могут не соответствовать действительности): \nШифровальщик : 2.2\nГенератор Заголовков : {random_string_version}\nМастер Автозагрузки : {autorun_master_version}\nОчистка Кэша : {clear_cache_version}\nФайловый Менеджер : {file_manager_version}\nВыход из программы : {exit_version}\nЛогирование Ошибок : {loging_errror_version}\nЗащита Нагрузки : {load_protection_version}\nАнлокер : {unlocker_version}\nПерезапуск : {restart_version}\nЗапуск : {run_version}\nИконка в Трее : {trey_version}\nО Программе : {about_program_version}\nПрочие Компоненты : {other_komponents_version}")
        def open_link(self, event):
            webbrowser.open("https://www.donationalerts.com/r/anonimneo")
        def open_link2(self, event):
            webbrowser.open("https://www.gnu.org/licenses/gpl-3.0.html")
        def open_link3(self, event):
            webbrowser.open("https://sites.google.com/view/neon-life")

    about_window = tk.Tk()
    app = ImageLoaderApp(about_window)
    about_window.mainloop()