#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
import win32com.client
import subprocess
import os

from LE import Loging_Error
from confing import *

restart_version = "0.7 Alpha"

global R_log_txt, restart_windows_bat

def R():
	global error, restart_windows
	try:
		if restart_windows == "win32com.client":
			win32api.InitiateSystemShutdown(
			    lpMachineName = "",
			    lpMessage = f"ОС будет перезагружена через {time_to_restart} секунд.",
			    dwTimeout = time_to_restart,
			    bForce = force_software,
			    bReboot = reboot_os
			)
		if restart_windows == "os":
			os.system("reboot")
		if restart_windows == "subprocess":
			subprocess.call(["shutdown", "/r", "/t", time_to_restart])
		if restart_windows == "bat":
			with open(restart_windows_bat, "w") as bat_file:
				bat_file.write(f"shutdown /r /t {time_to_restart}")
			os.startfile(restart_windows_bat)
	except Exception as e:
		Loging_Error("Произошла ошибка в Restart", R_log_txt, str(e))
		error = error + 1
		if error == 1:
			restart_windows = "win32com.client"
			R()
		if error == 2:
			restart_windows = "os"
			R()
		if error == 3:
			restart_windows = "subprocess"
			R()
		if error == 4:
			restart_windows = "bat"
			R()
		if error == 5:
			comment = "Были выполенны все способы перезагрузки windows, не одна не увенчалась успехом."
			print(comment)
			Loging_Error(comment, R_log_txt, str(e))