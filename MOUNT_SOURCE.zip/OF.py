#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
from tkinter import ttk, messagebox, filedialog
import subprocess
import sys
import os

from confing import *
from LE import Loging_Error

global file, file_size_o, LP_size, LP_path, PM_size, PM_path, MW_size, MW_path, EA_size

other_komponents_version = "0.2 beta"

#Запукс Компонентов
def Run_Komponent(file, file_size_o):
    try:
        #Проверяем, существует ли файл
        if not os.path.isfile(file):
            print("Файл не найден.")
            return

        #Получаем размер файла в байтах
        file_size = os.path.getsize(file)
        print(f"Размер файла: {file_size} байт")

        #Проверяем размер файла
        if file_size != file_size_o:
            comment = f"Размер файла {file} не равен {file_size_o} байтам. Программа не будет запущена.\nВОЗМОЖНОЕ УГРОЗА СИСТЕМЕ!"
            print(comment)
            if loging == "1":
                Loging_Error(comment, MU_log_txt, e)
            return

        #Запускаем файл
        if file_size == file_size_o:
            try:
                os.startfile(file)
            except Exception as e:
                print(f"Ошибка при запуске файла {file} : {e}")

    except Exception as e:
        comment = f"Не удалось запустить файл {file}"
        print(comment)
        if loging == "1":
            Loging_Error(comment, MU_log_txt, str(e))



#Открыть С помощью
def Open_With():
    target_file_path = filedialog.askopenfilename(title="Выберите файл для открытия", filetypes=[("Все файлы", "*.*")])
    if target_file_path and os.path.isfile(target_file_path): #Проверка, что файл выбран и существует
        app_path = filedialog.askopenfilename(title="Выберите программу для открытия файла", filetypes=[("Все файлы", "*.*")])
        if app_path:
            try:
                subprocess.Popen([app_path, target_file_path])
            except Exception as e:
                Random_String()
                messagebox.showerror(random_string, f"Не удалось открыть файл с помощью указанной программы:\n{str(e)}")



#Вызов функции Run_Komponent происхожит от сюда дабы программа при запуске не запускала все компоненты подряд (кароче де-баг)
def LP():
    Run_Komponent(LP_path, LP_size)