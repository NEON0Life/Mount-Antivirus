#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
def CC22(text, cod, decrypt=False):
    result = ""

    #Определяем длины алфавитов
    alphabet_lengths = {
        'en_lower': (ord('a'), 26),
        'en_upper': (ord('A'), 26),
        'ru_lower': (ord('а'), 33),
        'ru_upper': (ord('А'), 33)
    }

    #Изменяем смещение в зависимости от операции (шифрование или дешифрование)
    shift_amount = -cod if decrypt else cod

    for char in text: #Обработка Букв
        if char.isalpha():
            if 'a' <= char <= 'z': #английская буква (маленькая)
                base, length = alphabet_lengths['en_lower']
                shifted_char = chr((ord(char) - base + shift_amount) % length + base)
                result += shifted_char

            elif 'A' <= char <= 'Z': #английская буква (большая)
                base, length = alphabet_lengths['en_upper']
                shifted_char = chr((ord(char) - base + shift_amount) % length + base)
                result += shifted_char

            elif 'а' <= char <= 'я': #русская буква (маленькая)
                base, length = alphabet_lengths['ru_lower']
                shifted_char = chr((ord(char) - base + shift_amount) % length + base)
                result += shifted_char

            elif 'А' <= char <= 'Я': #русская буква (большая)
                base, length = alphabet_lengths['ru_upper']
                shifted_char = chr((ord(char) - base + shift_amount) % length + base)
                result += shifted_char

        elif char.isdigit(): #Обработка Чисел
            num = int(char)
            if decrypt == False:
                new_num = num * cod
            if decrypt == True:
                new_num = num / cod
            result += str(new_num)

        else:
            #Если символ не буква и не цифра, добавляем его без изменений
            result += char

    return result