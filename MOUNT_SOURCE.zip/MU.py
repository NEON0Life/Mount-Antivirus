#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
from tkinter import ttk, messagebox, Menu, simpledialog, filedialog
from datetime import datetime
import winreg as reg
import tkinter as tk
import subprocess
import random
import shutil
import os

#Импорт других файлов
from E import E
from R import R
from AR import AR
from confing import *
from LE import Loging_Error
from RS import Random_String
from OF import Run_Komponent, Open_With

unlocker_version = "1.7 Beta"

global loging, version, clyth, result, anpr, color_index, settings_path, animation_txt, MU_log_txt, random_string, animation_defolt, animation
random_string = ""
color_index = 0
animation = ""
result = ""
anpr = 0

def MU():
    try:
        def Animation_Read():
            try:
                if not os.path.exists(settings_path):
                    os.makedirs(settings_path)
                    with open(f"{settings_path}\\{animation_txt}", "w") as file:
                        file.write(animation_defolt)
                if not os.path.isfile(f"{settings_path}\\{animation_txt}"):
                    with open(f"{settings_path}\\{animation_txt}", "w") as file:
                        file.write(animation_defolt)
                with open(f"{settings_path}\\{animation_txt}", "r") as file:
                    animation = file.read()
                    print(animation)
                if animation == "False":
                    print("Первая проверка переменной animation пройдена")
                    anpr = 1
                if animation == "True":
                    print("Вторая проверка переменной animation пройдена")
                    anpr = 1
                if anpr == 0 :
                    print("Ни одна проверка переменной animation не пройдена")
                    animation = "False"
                print(animation)
            except FileNotFoundError:
                animation = "False"
                print(f"Ошибка чтения {animation_txt}, Значение - {animation}")

        Animation_Read()



        #def UA():
            #RGP()
            #print("Функция Недостпуна")



        mount_unlocker = tk.Tk()
        mount_unlocker.focus_force()
        style = ttk.Style()
        style.theme_use("clam")

        random_string = Random_String()
        mount_unlocker.title(random_string)

        header_text = "Монтировка Анлокер"
        header_label = tk.Label(mount_unlocker, font=("Arial", 32, "bold"))
        header_label.pack()

        #Каждая буква будет иметь свой цвет из радуги
        rainbow_colors = ["red", "orange", "yellow2", "green", "lightgreen", "blue", "skyblue", "violet"]
        color_index = 0 #Индекс текущего цвета

        def Change_Color():
            global color_index
            color = rainbow_colors[color_index]
            color_index = (color_index + 1) % len(rainbow_colors)
            header_label.config(fg=color)
            mount_unlocker.after(500, Change_Color)

        def Update_Text_Color(text, index, label):
            label.config(text=text[:index], fg=rainbow_colors[index % len(rainbow_colors)])
            mount_unlocker.after(150, Update_Text_Color, text, index+1, label)

        if animation == "True":
            Change_Color()
            Update_Text_Color(header_text, 0, header_label)



        #process_manager_button = tk.Button(mount_unlocker, text="Диспетчер процессов", command=, font=("Arial", 24))
        #process_manager_button.pack()
        #if animation == "True":
            #Update_Text_Color(process_manager_button.cget("text"), 0, process_manager_button)

        file_maneger_button = tk.Button(mount_unlocker, text="Файловый Менеджер", command=E, font=("Arial", 24))
        file_maneger_button.pack()
        if animation == "True":
            Update_Text_Color(file_maneger_button.cget("text"), 0, file_maneger_button)

        #unlock_button = tk.Button(mount_unlocker, text="Разблокировка всего", command=UA, font=("Arial", 24))
        #unlock_button.pack()
        #if animation == "True":
            #Update_Text_Color(unlock_button.cget("text"), 0, unlock_button)

        autoload_button = tk.Button(mount_unlocker, text="Автозагрузка", command=AR, font=("Arial", 24))
        autoload_button.pack()
        if animation == "True":
            Update_Text_Color(autoload_button.cget("text"), 0, autoload_button)

        copyright_label = tk.Label(mount_unlocker, text="Copyleft 🄯 NEON Life 2024 - 2025", anchor="w")
        copyright_label.pack(side="bottom", anchor="w", padx=10, pady=10)

        about_menu = tk.Menu(mount_unlocker)
        mount_unlocker.config(menu=about_menu)

        #Создание Меню
        main_menu = Menu(mount_unlocker)
        mount_unlocker.config(menu=main_menu)



        #Добавление Пункта "Утилиты"
        utilities_menu = Menu(main_menu, tearoff=0)
        main_menu.add_cascade(label="Утилиты", menu=utilities_menu)
        utilities_menu.add_command(label="Перезапустить ПК", command=R)
        utilities_menu.add_command(label="Открыть С Помощью", command=Open_With)

        mount_unlocker.mainloop()



    except Exception as e:
        comment = "В программе MountUnlocker возникла неизвестная ошибка!\n"
        print(comment)
        print(str(e))
        if loging == "1":
            Loging_Error(comment, MU_log_txt, str(e))