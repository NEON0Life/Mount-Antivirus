#Coded by @AnonimNEO
import win32com.client
import subprocess
import os

from LE import Loging_Error
from confing import *

restart_version = "0.7 Alpha"

global R_log_txt, restart_windows_bat

def R():
	global error, restart_windows
	try:
		if restart_windows == "win32com.client":
			win32api.InitiateSystemShutdown(
			    lpMachineName = "",
			    lpMessage = f"ОС будет перезагружена через {time_to_restart} секунд.",
			    dwTimeout = time_to_restart,
			    bForce = force_software,
			    bReboot = reboot_os
			)
		if restart_windows == "os":
			os.system("reboot")
		if restart_windows == "subprocess":
			subprocess.call(["shutdown", "/r", "/t", time_to_restart])
		if restart_windows == "bat":
			with open(restart_windows_bat, "w") as bat_file:
				bat_file.write(f"shutdown /r /t {time_to_restart}")
			os.startfile(restart_windows_bat)
	except Exception as e:
		Loging_Error("Произошла ошибка в Restart", R_log_txt, str(e))
		error = error + 1
		if error == 1:
			restart_windows = "win32com.client"
			R()
		if error == 2:
			restart_windows = "os"
			R()
		if error == 3:
			restart_windows = "subprocess"
			R()
		if error == 4:
			restart_windows = "bat"
			R()
		if error == 5:
			comment = "Были выполенны все способы перезагрузки windows, не одна не увенчалась успехом."
			print(comment)
			Loging_Error(comment, R_log_txt, str(e))