#Coded by @AnonimNEO
from tkinter import messagebox
from datetime import datetime
import tkinter as tk
import subprocess
import random
import os

from RS import Random_String
from LE import Loging_Error
from confing import *

global Run_log_txt

run_version = "0.7 Beta"

def Run():
    try:
        def Start_File_With_Admin(path):
            PO = 1
            if path == "C:\\Windows\\System32\\gpedit.msc":
                os.startfile(path)
                PO = 0
            if path == "C:\\Windows\\regedit.exe":
                os.startfile(path)
                PO = 0
            if PO == 1:
                try:
                    #Получаем имя текущего пользователя
                    username = os.getlogin()
                    print(f"Имя текущего пользователя: {username}")
                except Exception as e:
                    print("Не Удалось узнать имя пользователя!")

                #Проверяем Существует ли файл
                if os.path.exists(path):
                    try:
                        #Запускаем Файлик от имени администратора
                        subprocess.run(["runas", f"/user:{username}", path])
                    except Exception as e:
                        print(f"Ошибка при запуске: {str(e)}")
                        Loging_Error("Ошибка при запуске:", Run_log_txt,str(e))
                else:
                    comment = "Файл для запуска не найден!"
                    print(comment, str(e))
                    Loging_Error(comment, Run_log_txt,str(e))
                

        def Set_Path(path):
            entry.delete(0, tk.END)
            entry.insert(0, path)

        def On_OK():
            path = entry.get()
            Start_File_With_Admin(path)

        run = tk.Tk()
        Random_String()
        run.title(random_string)
        run.geometry("350x150")
        run.configure(bg="#2E2E2E")

        entry = tk.Entry(run, width=50)
        entry.pack(pady=10)

        ok_button = tk.Button(run, text="ОК", command=On_OK, bg="#444444", fg="white")
        ok_button.pack(pady=10)

        buttons_frame = tk.Frame(run, bg="#2E2E2E")
        buttons_frame.pack(pady=10)

        buttons = {
            "CMD": "C:\\Windows\\System32\\cmd.exe",
            "REGEDIT": "C:\\Windows\\regedit.exe",
            "GPEDIT": "C:\\Windows\\System32\\gpedit.msc",
            "POWERSHELL": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            "EXPLORER": "C:\\Windows\\explorer.exe"
        }

        for text, path in buttons.items():
            button = tk.Button(buttons_frame, text=text, command=lambda p=path: Set_Path(p), bg="#444444", fg="white")
            button.pack(side=tk.LEFT, padx=5)

        run.bind("<Return>", lambda event: on_ok())
        run.mainloop()

    except Exception as e:
        comment = "в Компоненте Run произошла неизвестаня ошибка!"
        print(comment, str(e))
        Loging_Error(comment, Run_log_txt, str(e))