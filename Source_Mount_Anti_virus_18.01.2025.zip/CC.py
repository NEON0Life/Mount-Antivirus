#Coded by @AnonimNEO
import datetime
import getpass
import shutil
import os

from LE import Loging_Error
from confing import *

global CC_log_txt, clear_temp_log, log_path, clear_temp_log

clear_cache_version = "0.6 Beta"

def CC():
    try:
        def Clean_Temp():
            print("Очитска Запущена")
            #Получаем имя пользователя
            username = getpass.getuser()
            temp_dir = f"C:\\Users\\{username}\\AppData\\Local\\Temp"

            #Переменные для логирования
            files_not_deleted = []
            files_deleted = []

            try:
                #Проходим по содержимому папки Temp
                for item in os.listdir(temp_dir):
                    item_path = os.path.join(temp_dir, item)
                    try:
                        if os.path.isfile(item_path):
                            os.remove(item_path)
                            files_deleted.append(item)
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)
                            files_deleted.append(item)
                    except Exception as e:
                        files_not_deleted.append(item)

                #Получаем текущее время и дату для имени лог-файла
                current_time = datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
                log_filename = f"{log_path}\\{clear_temp_log}_{current_time}.txt"
                if not os.path.exists(log_path):
                    os.makedirs(log_path)
                with open(log_filename, "w") as log_file:
                    log_file.write("Ошибка при удалении следующих файлов:\n")
                    for file in files_not_deleted:
                        log_file.write(f"{file}\n")
                    log_file.write("\nУспешно удалёные файлы:\n")
                    for file in files_deleted:
                        log_file.write(f"{file}\n")

                print(f"Лог файл {log_path}\\'{log_filename}' был создан.")
            except Exception as e:
                print(f"Произошла ошибка: {e}")
                Loging_Error("В ClearCache произошла неизвестаная ошибка", CC_log_txt, str(e))

        Clean_Temp()

    except Exception as e:
        Loging_Error("В ClearCache произошла неизвестаная ошибка", CC_log_txt, str(e))