#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
import subprocess
import random
import shutil
import sys
import os
#from pyqadmin import admin

from LR import Create_Label
from LE_setup import Loging_Error

CaC_version = "0.6 beta"

def run_command(command):
    #Запускает команду и ждём её завершения
    process = subprocess.run(command, shell=True)
    return process.returncode


#@admin
def move_all_files(src_folder, dest_folder):
    #Перемещает все содержимое указанной папки в другую папку
    try:
        for item in os.listdir(src_folder):
            src_path = os.path.join(src_folder, item)
            dest_path = os.path.join(dest_folder, item)
            if os.path.isdir(src_path):
                shutil.copytree(src_path, dest_path)
            else:
                shutil.move(src_path, dest_path)
        print(f"Содержимое {src_folder} перемещено в {dest_folder}.")
    except Exception as e:
        print(f"Ошибка при перемещении файлов: {e}")



def Update_Confing(file_name, LP_path):
    #Получаем размер файла в байтах
    try:
        file_size = os.path.getsize(file_name)
        file_size = int(file_size)
    except FileNotFoundError:
        print(f"Файл {file_name} не найден.")
        file_size = 0

    #Если размер файла успешно получен, записываем его вес в confing.py
    if file_size != 0:
        with open("config.py", "w") as config_file:
            if file_name == "LP.exe":
                config_file.write(f'\nLP_apth = "{LP_path}"\nLP_size = {file_size}\n')
        print(f"Вес файла {file_name} равен {file_size} байт, и записан в confing.py")



def Rename_Files(old_name, new_name):
    try:
        os.rename(old_name, new_name)
        print(f"Файл '{old_name}' был успешно переименован в '{new_name}'")
    except FileNotFoundError:
        comment = f"Файл '{old_name}' не найден."
        print(comment)
        Loging_Error(comment, "Mount_Setup_Log.txt", str(e))
    except Exception as e:
        comment = f"Произошла ошибка при переименовании файла {old_name} на {new_name}:\n {str(e)}"
        print(comment)
        Loging_Error(comment, "Mount_Setup_Log.txt", str(e))



#@admin
def move_files(path_to_setup, image_path, T_path, LP_path):
    #Перемещаем Компоненты
    shutil.copy(T_path, path_to_setup)
    shutil.copy(LP_path, path_to_setup)

    #Перемещаем содержимое папки info_image
    info_image_folder = "info_image"
    move_all_files(info_image_folder, image_path)

    #Перемещаем содержимое папки data в C:\\Windows\\Media\\
    data_folder = "data"
    move_all_files(data_folder, "C:\\Windows\\Media\\")



def Compilation(path_to_setup, T_path, LP_path, image_path):
    #Первая команда
    print("Компиляция Компонента LoadProtection запущена...")
    if run_command(f'python -m nuitka --follow-imports --standalone --windows-console-mode=disable --onefile --enable-plugin=tk-inter --windows-icon-from-ico=icon\\LP_icon.ico LP.py') == 0:
        print("Компиляция Компонента LoadProtection завершена!")

        #Обновляем confing.py, записывая туда расположение и вес Компонентов
        Update_Confing("LP.exe", LP_path)

        #Вторая команда
        print("Компиляция Компонента Trey запущена...")
        if run_command(f'python -m nuitka --follow-imports --standalone --windows-console-mode=disable --onefile --enable-plugin=tk-inter --windows-icon-from-ico=icon\\T_icon.ico T.py') == 0:
            print("Компиляция Компонента Trey завершена!")

            #Переименовываем Компоненты
            Rename_Files("LP.exe", LP_path)
            Rename_Files("T.exe", T_path)

            #Перемещаем файлы
            move_files(path_to_setup, image_path, T_path, LP_path)
            
            print("Процесс Компиляции и Установки Компонентов успешно завершён.")
            target_exe = path_to_setup + f"\\{T_path}"
            n = random.randint(4, 15)
            label_name = ''.join(random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(n))
            label_name = label_name + ".lnk"
            Create_Label(target_exe, label_name)
        else:
            comment = "Ошибка при компиляции Компонента Trey!"
            print(comment)
            Loging_Error(comment, "Mount_Setup_Log.txt", str(e))
    else:
        comment = "Ошибка при компиляции Компонента LoadProtection!"
        print(comment)
        Loging_Error(comment, "Mount_Setup_Log.txt", str(e))