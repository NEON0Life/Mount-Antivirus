#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
import tkinter as tk
from tkinter import messagebox
#Работа с Архивами
import zipfile
#Получение прав Администратора
#from elevate import elevate
import os

#elevate()

from IC import IC
from LE_setup import Loging_Error

global python_x32, python_x64, library_bat, MU_zip_file, e
python_x32 = "python-3.12.0-amd32.exe"
python_x64 = "python-3.12.0-amd64.exe"
library_bat = "install_library.bat"
MU_zip_file = "MU.zip"
e = ""
I_version = "0.6 beta"

class Setup_App:
    def Start_File(file_name):
        print(f"Запуск файла {file_name}")
        try:
            os.startfile(file_name)
        except Exception as e:
            comment = f"Ошибка при запуске файла {file_name}"
            print(f"{comment}\n{str(e)}")

    def Install_Python_x32(self):
        Start_File(python_x32)

    def Install_Python_x64(self):
        Start_File(python_x64)

    def Install_Libraries(self):
        Start_File(library_bat)

    def Start_Installation(self):
        try:
            with zipfile.ZipFile(MU_zip_file, "r") as zip_ref:
                #Распаковка Архива в Указанную Папку
                zip_ref.extractall("")
                print(f"Архив {MU_zip_file} успешно распакован в каталог установки")
        except Exception as e:
            print(f"Ошибка при распаковки архива {MU_zip_file}: {e}")
            Loging_Error(f"Ошибка Распаковки архива {MU_zip_file}", "Mount_Setup_Log.txt", str(e))
        IC()

    #def Import_Config(self):
        #response = messagebox.askyesno("Продолжить?", "Сейчас самое время заменить файл 'confing.py' на свой\nпосле импортирования нажмите кнопку 'Да'\nЕсли передумали это делать нажмите кнопку 'Нет'")

        #if response: #Если пользователь нажал "Да"
            #pass
        #else:
            #return

    def Show_Licenses(self):
        messagebox.showinfo("Лицензии", "Все Лицензии данного програмного обеспечения и используемых в ней библиотек,\nВы можете прочесть в файлах COPYING и LICENSE\nв каталоге установки или же в архиве")

    def __init__(self, Setup_App):
        self.Setup_App = Setup_App
        self.Setup_App.title("Установка Python")
        
        #Текст сверху
        self.top_frame = tk.Frame(Setup_App)
        self.top_frame.pack(fill=tk.X)

        self.label = tk.Label(self.top_frame, text="Выберите действие:", font=("Arial", 16))
        self.label.pack(pady=10)

        #Кнопки
        self.button_frame = tk.Frame(Setup_App)
        self.button_frame.pack(pady=10)

        self.buttons = [
            ("Установка Python 3.12.0 x32", self.Install_Python_x32),
            ("Установка Python 3.12.0 x64", self.Install_Python_x64),
            ("Установка Библиотек", self.Install_Libraries),
            ("Начать Установку", self.Start_Installation),
            #("Импортировать свой Конфинг", self.Import_Config),
            ("ЛИЦЕНЗИИ", self.Show_Licenses)
        ]

        for button_text, command in self.buttons:
            button = tk.Button(self.button_frame, text=button_text, width=30, command=command)
            button.pack(pady=5)

        #Надпись снизу
        self.bottom_frame = tk.Frame(Setup_App)
        self.bottom_frame.pack(side=tk.BOTTOM, fill=tk.X)

        self.footer_label = tk.Label(self.bottom_frame, text="NEON Life Copyleft 🄯 2024 - 2025", font=("Roboto", 10))
        self.footer_label.pack(pady=5)

        #Обработка изменения размера окна
        self.Setup_App.bind("<Configure>", self.On_Resize)

    def On_Resize(self, event):
        #Изменяем размер элементов при изменении размера окна
        width = self.Setup_App.winfo_width()
        self.label.config(font=("Roboto", int(width // 30))) #Изменяем размер шрифта для текста
        for button in self.button_frame.winfo_children():
            button.config(width=width // 20) #Пропорционально изменяем ширину кнопок
        self.footer_label.config(font=("Roboto", int(width // 50))) #Изменяем размер шрифта для надписи снизу

if __name__ == "__main__":
    Setup_Window = tk.Tk()
    app = Setup_App(Setup_Window)
    Setup_Window.geometry("750x375")
    Setup_Window.mainloop()