#Данное Свободное Програмное Обеспечение распространяется по лицензии GPL-2.0-only или GPL-2.0-or-later
#Вы имеете право копировать, изменять, распространять, взимать плату за физический акт передачи копии, и вы можете по своему усмотрению предлагать гарантийную защиту в обмен на плату(в случае её распространения)
#ДЛЯ ИСПОЛЬЗОВАНИЯ ДАННОГО СВОБОДНОГО ПРОГРАМНОГО ОБЕСПЕЧЕНИЯ, ВАМ НЕ ТРЕБУЕТСЯ ПРИНЯТИЕ ЛИЦЕНЦИИ Gnu GPL v2.0 или более поздней
#В СЛУЧАЕ РАСПРОСТРАНЕНИЯ ОРИГИНАЛЬНОЙ ПРОГРАММЫ И/ИЛИ МОДЕРНЕЗИРОВАНОЙ ВЕРСИИ И/ИЛИ ИСПОЛЬЗОВАНИЕ ИСХОДНИКОВ В СВОЕЙ ПРОГРАММЫ, ВЫ ОБЯЗАНЫ ЗАДОКУМЕНТИРОВАТЬ ВСЕ ИЗМЕНЕНИЯ В КОДЕ И ПРЕДОСТАВИТЬ ПОЛЬЗОВАТЕЛЯМ ВОЗМОЖНОСТЬ ПОЛУЧИТЬ ИСХОЖНИКИ ВАШЕЙ КОПИИ ПРОГРАММЫ, А ТАКЖЕ УКАЗАТЬ АВТОРСТВО ДАНОГО ПРОГРАМНОГО ОБЕЧПЕЧЕНИЯ
#ПРИ РАСПРАСТРАНЕНИИ ПРОГРАММЫ ВЫ ОБЯЗАНЫ ПРЕДОСТАВИТЬ ВСЕ ТЕЖЕ ПРАВА ПОЛЬЗОВАТЕЛЮ ЧТО И МЫ ВАМ
#Прочитать полную версию лицензии вы можете по ссылке Фонда Свободного Програмного Обсечпечения - https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#Или в файле COPYING в архиве с установщиком программы
#Copyleft 🄯 NEON Life Departament K 2024 - 2025
#Coded by @AnonimNEO (Telegram)
import tkinter as tk
import os

from CaC import Compilation
from LE_setup import Loging_Error

IC_version = "0.3 beta"

def IC():
    try:
        def Save_Config():
            with open("confing.py", "a") as f:
                for i, (label, var) in enumerate(zip(labels, entries)):
                    if i == 0:
                        f.write(f'\nsettings_path = "{var.get()}"\n')
                    if i == 1:
                        f.write(f'log_path = "{var.get()}"\n')
                    if i == 2:
                        f.write(f'images_path = "{var.get()}"\n')
                        global image_path
                        image_path = var.get()
                    if i == 3:
                        f.write(f'message_txt = "{var.get()}"\n')
                    if i == 4:
                        f.write(f'loging_txt = "{var.get()}"\n')
                    if i == 5:
                        f.write(f'animation_txt = "{var.get()}"\n')
                    if i == 6:
                        f.write(f'bad_process_txt = "{var.get()}"\n')
                    if i == 7:
                        f.write(f'ultimate_load_cpu_txt = "{var.get()}"\n')
                    if i == 8:
                        f.write(f'ultimate_load_gpu_txt = "{var.get()}"\n')
                    if i == 9:
                        f.write(f'ultimate_load_ram_txt = "{var.get()}"\n')
                    if i == 10:
                        f.write(f'ultimate_load_lan_txt = "{var.get()}"\n')
                    if i == 11:
                        f.write(f'exception_process = "{var.get()}"\n')
                    if i == 12:
                        f.write(f'emergency_alert_mp3 = "{var.get()}"\n')
                    if i == 13:
                        f.write(f'restart_windows_bat = "{var.get()}"\n')
                    if i == 14:
                        f.write(f'clear_temp_log = "{var.get()}"\n')
                    if i == 15:
                        f.write(f'AR_log_txt = "{var.get()}"\n')
                    if i == 16:
                        f.write(f'CC_log_txt = "{var.get()}"\n')
                    if i == 17:
                        f.write(f'E_log_txt = "{var.get()}"\n')
                    if i == 18:
                        f.write(f'exit_T_log_txt = "{var.get()}"\n')
                    if i == 19:
                        f.write(f'LP_log_txt = "{var.get()}"\n')
                    if i == 20:
                        f.write(f'MU_log_txt = "{var.get()}"\n')
                    if i == 21:
                        f.write(f'R_log_txt = "{var.get()}"\n')
                    if i == 22:
                        f.write(f'Run_log_txt = "{var.get()}"\n')
                    if i == 23:
                        f.write(f'T_log_txt = "{var.get()}"\n')
                    if i == 24:
                        f.write(f'clyth = {var.get()}\n')
                    if i == 25:
                        f.write(f'loging = "{var.get()}"\n')
                    if i == 26:
                        f.write(f'message = "{var.get()}"\n')
                    if i == 27:
                        f.write(f'alert_sound = "{var.get()}"\n')
                    if i == 28:
                        f.write(f'restart_windows = "{var.get()}"\n')
                    if i == 29:
                        f.write(f'time_to_restart = "{var.get()}"\n')
                    if i == 30:
                        f.write(f'reboot_os = {var.get()}\n')
                    if i == 31:
                        f.write(f'force_software = {var.get()}\n')
                    if i == 32:
                        f.write(f'user_name = "{var.get()}"\n')
                    if i == 33:
                        f.write(f'open_with = {var.get()}\n')
                    if i == 34:
                        f.write(f'time_sleep_to_scan = {var.get()}\n')
                    if i == 35:
                        f.write(f'ultimate_load_cpu = {var.get()}\n')
                    if i == 36:
                        f.write(f'ultimate_load_gpu = {var.get()}\n')
                    if i == 37:
                        f.write(f'ultimate_load_ram = {var.get()}\n')
                    if i == 38:
                        f.write(f'ultimate_load_lan = {var.get()}\n')
                    if i == 39:
                        f.write(f'animation_defolt = "{var.get()}"\n')
                    if i == 40:
                        f.write(f'LP_path = "{var.get()}"\n')
                        global LP_path
                        LP_path = var.get()
                    if i == 41:
                        global T_path
                        T_path = var.get()
                    if i == 42:
                        global path_to_setup
                        path_to_setup = var.get()

                    print(f'В confing.py добавлен параметр: {label} = "{var.get()}"')
            print("confing.py - сохранён.\nЗапуск Компиляции...")
            Compilation(path_to_setup, T_path, LP_path, image_path)

        #Окно Настройки
        configuret_window = tk.Tk()
        configuret_window.title("Настройка Конфигурации Антивируса Монтировка")
        configuret_window.geometry("475x450")

        #Ползунок Прокрутки
        frame = tk.Frame(configuret_window)
        frame.pack(fill=tk.BOTH, expand=True)

        canvas = tk.Canvas(frame)
        scrollbar = tk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

        canvas.configure(yscrollcommand=scrollbar.set)

        #Параметры
        labels = [
            "Введите имя каталога настроек программы",
            "Введите имя каталога настроек лог файлов",
            "Введите путь к каталогу в котором будут находится картинки\nC:\\ProgramData\\ - по умолчанию",
            "Введите имя файла настройки переменной message\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной loging\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной animationn\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной bad_process\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной ultimate_load_cpu\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной ultimate_load_gpu\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной ultimate_load_ram\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной ultimate_load_lan\n(лучше указать расширение файла - .txt)",
            "Введите имя файла настройки переменной exception_process\n(лучше указать расширение файла - .txt)",
            "Введите имя файла аудио тревоги\nУКАЗЫВАТЬ С РАСШИРЕНИЕМ .mp3!",
            "Введите имя .bat файла для перезагрузки\nУКАЗЫВАТЬ С РАСШИРЕНИЕМ .bat!",
            "Введите имя лог файла результата очистки кэша\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента AutoRunMaster\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента ClearCache\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента Explorer\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента Выхода из Программы\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента LoadProtection\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента MountUnlocker\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента Restart\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента Run\n(лучше указать расширение файла - .txt)",
            "Введите имя лог файла Компонента Trey\n(лучше указать расширение файла - .txt)",
            "Введите Ключ Шифрования",
            "Введите значение переменной loging 1 - для логирования ошибок | 0 - для игнорирования",
            "Введите значение переменной message: True - включить подробные уведомления в компонентах | False - выключить",
            "Введите значение переменной alert_sound: звук тревоги при обнаружении угроз? True - да | False - нет",
            "Введите способ перезагрузки ОС : win32com.client, subprocess, os, bat - (ЕДИНСТВЕННЫЙ СТАБИЛЬНЫЙ)",
            "Введите количество секунд до выполнения перезагрузки",
            "Перезапускать или Выключать ОС? True - Перезапуск | False - Выключение",
            "Насильно закрыть программы при перезапуски или выключении? True - да | False - нет",
            "Введите имя пользователя которое будет использоватся в Компоненте Explorer, в случае ошибки получения текущего имени пользователя",
            "Добавить ли в контекстное меню Компонента Explorer пункт 'Открыть с помощью'\nПримечание - данная опция открывает окно где вам всё равно нажо будет выбрать файл: 1 - Да | 0 - нет",
            "Введите количество секунд до повторного сканирования поцессов в Компоненте LoadProtection",
            "Введите предельное количество нагрузки на CPU в %",
            "Введите предельное количество нагрузки на GPU в %",
            "Введите предельное количество нагрузки на RAM в %",
            "Введите предельное количество нагрузки на LAN в %",
            "Введите значение анимации в анлокере по умолчанию True - да | False - нет",
            "Введите имя файла Компонента LoadProtection\nУКАЗЫВАТЬ С РАСШИРЕНИЕМ .exe!",
            "Введите имя файла Компонента Trey\nУКАЗЫВАТЬ С РАСШИРЕНИЕМ .exe!",
            "Введите каталог куда будет установлено данное программное обеспечение"
        ]

        entries = []

        for label in labels:
            row = tk.Frame(scrollable_frame)
            label_widget = tk.Label(row, text=label, anchor="w", wraplength=300)
            entry_widget = tk.Entry(row)
            label_widget.grid(row=0, column=0, sticky="w")
            entry_widget.grid(row=0, column=1, sticky="ew")
            row.pack(pady=5)
            entries.append(entry_widget)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        save_button = tk.Button(configuret_window, text="Начать Компиляцию", command=Save_Config)
        save_button.pack(pady=10)

        configuret_window.mainloop()

    except Exception as e:
        comment = "Произошла неизвестная ошибка в Компоненте InstallConfing!"
        print(f"{comment}\n{str(e)}")
        Loging_Error(comment, "Mount_Setup_Log.txt", str(e))